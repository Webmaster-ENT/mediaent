import { withCtx, unref, createVNode, openBlock, createBlock, Fragment, renderList, toDisplayString, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrInterpolate } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./HomeLayout-6d6c8674.mjs";
import { Link } from "@inertiajs/inertia-vue3";
import { UserCircleIcon, HandThumbUpIcon, ChatBubbleLeftEllipsisIcon } from "@heroicons/vue/24/solid";
import "@headlessui/vue";
import "@heroicons/vue/24/outline";
import "./DropdownLink-8164274e.mjs";
import "./_plugin-vue_export-helper-cc2b3d55.mjs";
const Forum_vue_vue_type_style_index_0_setup_true_lang = "";
const _sfc_main = {
  __name: "Forum",
  __ssrInlineRender: true,
  props: {
    forums: Object
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$1, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="bg-sky-900"${_scopeId}><div class="max-w-xs mx-auto overflow-hidden md:max-w-5xl lg:max-w-7xl"${_scopeId}><!--[-->`);
            ssrRenderList(__props.forums, (forum) => {
              _push2(`<div${_scopeId}><div${_scopeId}><div class="py-4 md:py-6 md:ml-24 lg:p-8"${_scopeId}><div class="flex"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(UserCircleIcon), { class: "text-white w-10 h-10 md:w-12 md:h-12 lg:w-14 lg:h-14" }, null, _parent2, _scopeId));
              _push2(`<div class="mt-1.5"${_scopeId}><div class="ml-3 uppercase tracking-wide text-xs text-white font-medium md:text-base lg:text-lg"${_scopeId}>${ssrInterpolate(forum.user.name)}</div><p class="ml-3 font-medium text-slate-400 text-xs md:text-sm lg:text-base font"${_scopeId}> Asked On ${ssrInterpolate(forum.created_at)} WIB </p>`);
              _push2(ssrRenderComponent(unref(Link), {
                href: _ctx.route("detail-forum.showforum", forum.slug)
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`<div class="mt-2 ml-3 text-white font-semibold mt-7 text-base md:text-xl lg:text-2xl"${_scopeId2}>${forum.subject}</div>`);
                  } else {
                    return [
                      createVNode("div", {
                        class: "mt-2 ml-3 text-white font-semibold mt-7 text-base md:text-xl lg:text-2xl",
                        innerHTML: forum.subject
                      }, null, 8, ["innerHTML"])
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              _push2(`<div class="mt-4 md:mt-6"${_scopeId}><div class="flex ml-3 text-white items-center text-sm md:text-xl"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(HandThumbUpIcon), { class: "w-4 h-4 md:w-5 md:h-5 lg:w-6 lg:h-6" }, null, _parent2, _scopeId));
              _push2(`<span class="mx-2 mr-6"${_scopeId}>${ssrInterpolate(forum.likes.length)}</span>`);
              _push2(ssrRenderComponent(unref(ChatBubbleLeftEllipsisIcon), { class: "w-4 h-4 md:w-5 md:h-5 lg:w-6 lg:h-6" }, null, _parent2, _scopeId));
              _push2(`<span class="mx-2"${_scopeId}>${ssrInterpolate(forum.comments.length)}</span></div></div></div></div></div></div><hr class="m-auto border-t-2 my-2 w-4/5"${_scopeId}></div>`);
            });
            _push2(`<!--]--></div></div>`);
          } else {
            return [
              createVNode("div", { class: "bg-sky-900" }, [
                createVNode("div", { class: "max-w-xs mx-auto overflow-hidden md:max-w-5xl lg:max-w-7xl" }, [
                  (openBlock(true), createBlock(Fragment, null, renderList(__props.forums, (forum) => {
                    return openBlock(), createBlock("div", {
                      key: forum.id
                    }, [
                      createVNode("div", null, [
                        createVNode("div", { class: "py-4 md:py-6 md:ml-24 lg:p-8" }, [
                          createVNode("div", { class: "flex" }, [
                            createVNode(unref(UserCircleIcon), { class: "text-white w-10 h-10 md:w-12 md:h-12 lg:w-14 lg:h-14" }),
                            createVNode("div", { class: "mt-1.5" }, [
                              createVNode("div", { class: "ml-3 uppercase tracking-wide text-xs text-white font-medium md:text-base lg:text-lg" }, toDisplayString(forum.user.name), 1),
                              createVNode("p", { class: "ml-3 font-medium text-slate-400 text-xs md:text-sm lg:text-base font" }, " Asked On " + toDisplayString(forum.created_at) + " WIB ", 1),
                              createVNode(unref(Link), {
                                href: _ctx.route("detail-forum.showforum", forum.slug)
                              }, {
                                default: withCtx(() => [
                                  createVNode("div", {
                                    class: "mt-2 ml-3 text-white font-semibold mt-7 text-base md:text-xl lg:text-2xl",
                                    innerHTML: forum.subject
                                  }, null, 8, ["innerHTML"])
                                ]),
                                _: 2
                              }, 1032, ["href"]),
                              createVNode("div", { class: "mt-4 md:mt-6" }, [
                                createVNode("div", { class: "flex ml-3 text-white items-center text-sm md:text-xl" }, [
                                  createVNode(unref(HandThumbUpIcon), { class: "w-4 h-4 md:w-5 md:h-5 lg:w-6 lg:h-6" }),
                                  createVNode("span", { class: "mx-2 mr-6" }, toDisplayString(forum.likes.length), 1),
                                  createVNode(unref(ChatBubbleLeftEllipsisIcon), { class: "w-4 h-4 md:w-5 md:h-5 lg:w-6 lg:h-6" }),
                                  createVNode("span", { class: "mx-2" }, toDisplayString(forum.comments.length), 1)
                                ])
                              ])
                            ])
                          ])
                        ])
                      ]),
                      createVNode("hr", { class: "m-auto border-t-2 my-2 w-4/5" })
                    ]);
                  }), 128))
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/FrontEnd/Forum.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
