import { mergeProps, withCtx, unref, createTextVNode, toDisplayString, createVNode, withModifiers, withDirectives, vModelSelect, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate } from "vue/server-renderer";
import { _ as _sfc_main$4 } from "./InputError-f49a19bd.mjs";
import { _ as _sfc_main$2 } from "./InputLabel-fec3cbb9.mjs";
import { _ as _sfc_main$1, a as _sfc_main$5 } from "./SecondaryButton-9c5ff5e4.mjs";
import { _ as _sfc_main$6 } from "./PrimaryButton-78b55991.mjs";
import "./SelectInput-14884544.mjs";
import { _ as _sfc_main$3 } from "./TextInput-a82a0582.mjs";
import { useForm } from "@inertiajs/inertia-vue3";
const _sfc_main = {
  __name: "Create",
  __ssrInlineRender: true,
  props: {
    show: Boolean
  },
  emits: ["close"],
  setup(__props, { emit }) {
    const props = __props;
    const form = useForm({
      title: "",
      video_url: "https://www.youtube.com/embed/",
      status: "draft"
    });
    const create = () => {
      form.post(route("video.store"), {
        preserveScroll: true,
        onSuccess: () => {
          emit("close");
          form.reset();
        },
        onError: () => null,
        onFinish: () => null
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "space-y-6" }, _attrs))}>`);
      _push(ssrRenderComponent(_sfc_main$1, {
        show: props.show,
        onClose: ($event) => emit("close")
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<form class="p-6"${_scopeId}><h2 class="text-lg font-medium text-gray-900 dark:text-gray-100"${_scopeId}> Add Video Url </h2><div class="my-6 space-y-4"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "title",
              value: "Title"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              id: "name",
              type: "text",
              class: "mt-1 block w-full",
              modelValue: unref(form).title,
              "onUpdate:modelValue": ($event) => unref(form).title = $event,
              required: "",
              placeholder: "Title"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              class: "mt-2",
              message: unref(form).errors.title
            }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="my-6 space-y-4"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "title",
              value: "Link YouTube-Embed"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              id: "video_url",
              type: "text",
              class: "mt-1 block w-full",
              modelValue: unref(form).video_url,
              "onUpdate:modelValue": ($event) => unref(form).video_url = $event,
              required: "",
              placeholder: "https://www.youtube.com/embed/xxx..."
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              class: "mt-2",
              message: unref(form).errors.title
            }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="my-6 space-y-4"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "status",
              value: "Status"
            }, null, _parent2, _scopeId));
            _push2(`<select id="status" class="mt-1 block w-full border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm placeholder:text-gray-400 placeholder:dark:text-gray-400/50"${_scopeId}><option value="draft" selected${_scopeId}>Draft</option><option value="show"${_scopeId}>Show</option></select></div><div class="flex justify-end"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$5, {
              disabled: unref(form).processing,
              onClick: ($event) => emit("close")
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.lang().button.close)}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.lang().button.close), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$6, {
              class: ["ml-3", { "opacity-25": unref(form).processing }],
              disabled: unref(form).processing,
              onClick: create
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref(form).processing ? _ctx.lang().button.add + "..." : _ctx.lang().button.add)}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(unref(form).processing ? _ctx.lang().button.add + "..." : _ctx.lang().button.add), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></form>`);
          } else {
            return [
              createVNode("form", {
                class: "p-6",
                onSubmit: withModifiers(create, ["prevent"])
              }, [
                createVNode("h2", { class: "text-lg font-medium text-gray-900 dark:text-gray-100" }, " Add Video Url "),
                createVNode("div", { class: "my-6 space-y-4" }, [
                  createVNode("div", null, [
                    createVNode(_sfc_main$2, {
                      for: "title",
                      value: "Title"
                    }),
                    createVNode(_sfc_main$3, {
                      id: "name",
                      type: "text",
                      class: "mt-1 block w-full",
                      modelValue: unref(form).title,
                      "onUpdate:modelValue": ($event) => unref(form).title = $event,
                      required: "",
                      placeholder: "Title"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                    createVNode(_sfc_main$4, {
                      class: "mt-2",
                      message: unref(form).errors.title
                    }, null, 8, ["message"])
                  ])
                ]),
                createVNode("div", { class: "my-6 space-y-4" }, [
                  createVNode("div", null, [
                    createVNode(_sfc_main$2, {
                      for: "title",
                      value: "Link YouTube-Embed"
                    }),
                    createVNode(_sfc_main$3, {
                      id: "video_url",
                      type: "text",
                      class: "mt-1 block w-full",
                      modelValue: unref(form).video_url,
                      "onUpdate:modelValue": ($event) => unref(form).video_url = $event,
                      required: "",
                      placeholder: "https://www.youtube.com/embed/xxx..."
                    }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                    createVNode(_sfc_main$4, {
                      class: "mt-2",
                      message: unref(form).errors.title
                    }, null, 8, ["message"])
                  ])
                ]),
                createVNode("div", { class: "my-6 space-y-4" }, [
                  createVNode(_sfc_main$2, {
                    for: "status",
                    value: "Status"
                  }),
                  withDirectives(createVNode("select", {
                    id: "status",
                    "onUpdate:modelValue": ($event) => unref(form).status = $event,
                    class: "mt-1 block w-full border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm placeholder:text-gray-400 placeholder:dark:text-gray-400/50"
                  }, [
                    createVNode("option", {
                      value: "draft",
                      selected: ""
                    }, "Draft"),
                    createVNode("option", { value: "show" }, "Show")
                  ], 8, ["onUpdate:modelValue"]), [
                    [vModelSelect, unref(form).status]
                  ])
                ]),
                createVNode("div", { class: "flex justify-end" }, [
                  createVNode(_sfc_main$5, {
                    disabled: unref(form).processing,
                    onClick: ($event) => emit("close")
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(_ctx.lang().button.close), 1)
                    ]),
                    _: 1
                  }, 8, ["disabled", "onClick"]),
                  createVNode(_sfc_main$6, {
                    class: ["ml-3", { "opacity-25": unref(form).processing }],
                    disabled: unref(form).processing,
                    onClick: create
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(unref(form).processing ? _ctx.lang().button.add + "..." : _ctx.lang().button.add), 1)
                    ]),
                    _: 1
                  }, 8, ["class", "disabled"])
                ])
              ], 40, ["onSubmit"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Video/Create.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
