import { unref, mergeProps, withCtx, createVNode, openBlock, createBlock, createTextVNode, toDisplayString, createCommentVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderAttr, ssrInterpolate, ssrRenderAttrs, ssrRenderStyle, ssrRenderSlot } from "vue/server-renderer";
import { Disclosure, DisclosureButton, DisclosurePanel } from "@headlessui/vue";
import { Link } from "@inertiajs/inertia-vue3";
import { Bars3Icon, XMarkIcon } from "@heroicons/vue/24/outline";
import { UserIcon } from "@heroicons/vue/24/solid";
import { _ as _sfc_main$3, a as _sfc_main$4 } from "./DropdownLink-8164274e.mjs";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.mjs";
const _imports_0 = "/build/assets/Logo-ENT-Gelap-cf15fe6c.svg";
const _sfc_main$2 = {
  __name: "NavbarUser",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(Disclosure), mergeProps({
        as: "nav",
        class: "bg-white shadow"
      }, _attrs), {
        default: withCtx(({ open }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="mx-auto max-w-7xl px-2 sm:px-6 lg:px-8"${_scopeId}><div class="relative flex h-16 items-center justify-between"${_scopeId}><div class="absolute inset-y-0 left-0 flex items-center sm:hidden"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(DisclosureButton), { class: "inline-flex items-center justify-center rounded-md p-2 text-gray-400 hover:bg-gray-700 hover:text-white focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white" }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<span class="sr-only"${_scopeId2}>Open main menu</span>`);
                  if (!open) {
                    _push3(ssrRenderComponent(unref(Bars3Icon), {
                      class: "block h-6 w-6",
                      "aria-hidden": "true"
                    }, null, _parent3, _scopeId2));
                  } else {
                    _push3(ssrRenderComponent(unref(XMarkIcon), {
                      class: "block h-6 w-6",
                      "aria-hidden": "true"
                    }, null, _parent3, _scopeId2));
                  }
                } else {
                  return [
                    createVNode("span", { class: "sr-only" }, "Open main menu"),
                    !open ? (openBlock(), createBlock(unref(Bars3Icon), {
                      key: 0,
                      class: "block h-6 w-6",
                      "aria-hidden": "true"
                    })) : (openBlock(), createBlock(unref(XMarkIcon), {
                      key: 1,
                      class: "block h-6 w-6",
                      "aria-hidden": "true"
                    }))
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-1 items-center justify-center sm:items-stretch sm:justify-start"${_scopeId}><div class="flex flex-shrink-0 items-center mr-16"${_scopeId}><img class="block h-12 w-auto lg:hidden"${ssrRenderAttr("src", _imports_0)} alt="Logo ENT"${_scopeId}><img class="hidden h-12 w-auto lg:block"${ssrRenderAttr("src", _imports_0)} alt="Logo ENT"${_scopeId}></div><div class="hidden sm:ml-6 sm:block mt-1"${_scopeId}><div class="flex"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              key: "article",
              href: _ctx.route("all-article.allarticle"),
              class: "pl-3 py-2 rounded-md text-sm font-medium hover:font-bold"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Article`);
                } else {
                  return [
                    createTextVNode("Article")
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`<div class="relative"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$3, {
              align: "left",
              width: "48"
            }, {
              trigger: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<span class="inline-flex rounded-md"${_scopeId2}><button type="button" class="inline-flex items-center justify-center p-2 rounded-md transition duration-150 ease-in-out sm:hidden"${_scopeId2}>`);
                  _push3(ssrRenderComponent(unref(UserIcon), { class: "h-4 w-4" }, null, _parent3, _scopeId2));
                  _push3(`</button><button type="button" class="items-center justify-center mt-3 mr-7 font-medium hover:font-black text-sm normal-case transition duration-150 ease-in-out hidden sm:inline-flex"${_scopeId2}><i class="fa-solid fa-chevron-down ml-1 text-xs"${_scopeId2}></i></button></span>`);
                } else {
                  return [
                    createVNode("span", { class: "inline-flex rounded-md" }, [
                      createVNode("button", {
                        type: "button",
                        class: "inline-flex items-center justify-center p-2 rounded-md transition duration-150 ease-in-out sm:hidden"
                      }, [
                        createVNode(unref(UserIcon), { class: "h-4 w-4" })
                      ]),
                      createVNode("button", {
                        type: "button",
                        class: "items-center justify-center mt-3 mr-7 font-medium hover:font-black text-sm normal-case transition duration-150 ease-in-out hidden sm:inline-flex"
                      }, [
                        createVNode("i", { class: "fa-solid fa-chevron-down ml-1 text-xs" })
                      ])
                    ])
                  ];
                }
              }),
              content: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_sfc_main$4, {
                    href: _ctx.route("category.show", 1),
                    as: "button"
                  }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(` Lifestyle `);
                      } else {
                        return [
                          createTextVNode(" Lifestyle ")
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$4, {
                    href: _ctx.route("category.show", 2),
                    as: "button"
                  }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(` Hiburan `);
                      } else {
                        return [
                          createTextVNode(" Hiburan ")
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$4, {
                    href: _ctx.route("category.show", 3),
                    as: "button"
                  }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(` Teknologi `);
                      } else {
                        return [
                          createTextVNode(" Teknologi ")
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$4, {
                    href: _ctx.route("category.show", 4),
                    as: "button"
                  }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(` Otomotif `);
                      } else {
                        return [
                          createTextVNode(" Otomotif ")
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_sfc_main$4, {
                      href: _ctx.route("category.show", 1),
                      as: "button"
                    }, {
                      default: withCtx(() => [
                        createTextVNode(" Lifestyle ")
                      ]),
                      _: 1
                    }, 8, ["href"]),
                    createVNode(_sfc_main$4, {
                      href: _ctx.route("category.show", 2),
                      as: "button"
                    }, {
                      default: withCtx(() => [
                        createTextVNode(" Hiburan ")
                      ]),
                      _: 1
                    }, 8, ["href"]),
                    createVNode(_sfc_main$4, {
                      href: _ctx.route("category.show", 3),
                      as: "button"
                    }, {
                      default: withCtx(() => [
                        createTextVNode(" Teknologi ")
                      ]),
                      _: 1
                    }, 8, ["href"]),
                    createVNode(_sfc_main$4, {
                      href: _ctx.route("category.show", 4),
                      as: "button"
                    }, {
                      default: withCtx(() => [
                        createTextVNode(" Otomotif ")
                      ]),
                      _: 1
                    }, 8, ["href"])
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`</div>`);
            _push2(ssrRenderComponent(unref(Link), {
              key: "forum",
              href: _ctx.route("all-forum.allforum"),
              class: "px-7 py-2 rounded-md text-sm font-medium hover:font-bold"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Forum`);
                } else {
                  return [
                    createTextVNode("Forum")
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(Link), {
              key: "video",
              href: _ctx.route("all-video.allvideo"),
              class: "px-7 py-2 rounded-md text-sm font-medium hover:font-bold"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Video`);
                } else {
                  return [
                    createTextVNode("Video")
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(Link), {
              key: "about",
              class: "px-7 py-2 rounded-md text-sm font-medium hover:font-bold"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`About`);
                } else {
                  return [
                    createTextVNode("About")
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`</div></div></div>`);
            if (_ctx.$page.props.auth.user != null) {
              _push2(`<div class="flex"${_scopeId}>`);
              if (_ctx.$page.props.auth.user.name == "Superadmin") {
                _push2(`<div${_scopeId}>`);
                _push2(ssrRenderComponent(unref(Link), {
                  class: "bg-sky-900 rounded-full px-4 py-1 my-auto font-medium hover:font-bold hover:bg-yellow-700 text-sm normal-case text-white",
                  href: "/dashboard"
                }, {
                  default: withCtx((_, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(`Dashboard`);
                    } else {
                      return [
                        createTextVNode("Dashboard")
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
                _push2(`</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`<div class="relative"${_scopeId}>`);
              _push2(ssrRenderComponent(_sfc_main$3, {
                align: "right",
                width: "48"
              }, {
                trigger: withCtx((_, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`<span class="inline-flex rounded-md"${_scopeId2}><button type="button" class="inline-flex items-center justify-center p-2 rounded-md transition duration-150 ease-in-out sm:hidden"${_scopeId2}>`);
                    _push3(ssrRenderComponent(unref(UserIcon), { class: "h-4 w-4" }, null, _parent3, _scopeId2));
                    _push3(`</button><button type="button" class="ml-4 items-center justify-center bg-sky-300 rounded-full px-4 py-1 my-auto font-medium hover:font-bold hover:bg-yellow-700 text-sm normal-case text-sky-900 hover:text-white transition duration-150 ease-in-out hidden sm:inline-flex"${_scopeId2}><span class="flex justify-between items-center capitalize"${_scopeId2}>${ssrInterpolate(_ctx.$page.props.auth.user.name.split(" ")[0])}</span><i class="fa-solid fa-chevron-down ml-1 text-xs"${_scopeId2}></i></button></span>`);
                  } else {
                    return [
                      createVNode("span", { class: "inline-flex rounded-md" }, [
                        createVNode("button", {
                          type: "button",
                          class: "inline-flex items-center justify-center p-2 rounded-md transition duration-150 ease-in-out sm:hidden"
                        }, [
                          createVNode(unref(UserIcon), { class: "h-4 w-4" })
                        ]),
                        createVNode("button", {
                          type: "button",
                          class: "ml-4 items-center justify-center bg-sky-300 rounded-full px-4 py-1 my-auto font-medium hover:font-bold hover:bg-yellow-700 text-sm normal-case text-sky-900 hover:text-white transition duration-150 ease-in-out hidden sm:inline-flex"
                        }, [
                          createVNode("span", { class: "flex justify-between items-center capitalize" }, toDisplayString(_ctx.$page.props.auth.user.name.split(" ")[0]), 1),
                          createVNode("i", { class: "fa-solid fa-chevron-down ml-1 text-xs" })
                        ])
                      ])
                    ];
                  }
                }),
                content: withCtx((_, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(ssrRenderComponent(_sfc_main$4, {
                      href: _ctx.route("logout"),
                      method: "post",
                      as: "button"
                    }, {
                      default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`${ssrInterpolate(_ctx.lang().label.logout)}`);
                        } else {
                          return [
                            createTextVNode(toDisplayString(_ctx.lang().label.logout), 1)
                          ];
                        }
                      }),
                      _: 2
                    }, _parent3, _scopeId2));
                  } else {
                    return [
                      createVNode(_sfc_main$4, {
                        href: _ctx.route("logout"),
                        method: "post",
                        as: "button"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(toDisplayString(_ctx.lang().label.logout), 1)
                        ]),
                        _: 1
                      }, 8, ["href"])
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              _push2(`</div></div>`);
            } else {
              _push2(`<div${_scopeId}>`);
              _push2(ssrRenderComponent(unref(Link), {
                class: "bg-sky-900 rounded-full px-4 py-1 my-auto font-medium hover:font-bold hover:bg-yellow-700 text-sm normal-case text-white",
                href: "/login"
              }, {
                default: withCtx((_, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`Login`);
                  } else {
                    return [
                      createTextVNode("Login")
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              _push2(`</div>`);
            }
            _push2(`</div></div>`);
            _push2(ssrRenderComponent(unref(DisclosurePanel), { class: "sm:hidden" }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="space-y-1 px-2 pt-2 pb-3"${_scopeId2}><div class="flex"${_scopeId2}>`);
                  _push3(ssrRenderComponent(unref(DisclosureButton), {
                    key: "article",
                    as: "a",
                    href: _ctx.route("all-article.allarticle"),
                    class: "pl-7 py-2 rounded-md text-sm font-medium hover:font-bold"
                  }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`Article`);
                      } else {
                        return [
                          createTextVNode("Article")
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                  _push3(`<div class="relative"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_sfc_main$3, {
                    align: "left",
                    width: "48"
                  }, {
                    trigger: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<span class="inline-flex rounded-md"${_scopeId3}><button type="button" class="inline-flex items-center justify-center mt-3 mr-7 font-medium hover:font-bold text-sm normal-case hover:text-white transition duration-150 ease-in-out sm:hidden"${_scopeId3}><i class="fa-solid fa-chevron-down ml-1 text-xs"${_scopeId3}></i></button><button type="button" class="items-center justify-center mt-3 mr-7 font-medium hover:font-black text-sm normal-case transition duration-150 ease-in-out hidden sm:inline-flex"${_scopeId3}><i class="fa-solid fa-chevron-down ml-1 text-xs"${_scopeId3}></i></button></span>`);
                      } else {
                        return [
                          createVNode("span", { class: "inline-flex rounded-md" }, [
                            createVNode("button", {
                              type: "button",
                              class: "inline-flex items-center justify-center mt-3 mr-7 font-medium hover:font-bold text-sm normal-case hover:text-white transition duration-150 ease-in-out sm:hidden"
                            }, [
                              createVNode("i", { class: "fa-solid fa-chevron-down ml-1 text-xs" })
                            ]),
                            createVNode("button", {
                              type: "button",
                              class: "items-center justify-center mt-3 mr-7 font-medium hover:font-black text-sm normal-case transition duration-150 ease-in-out hidden sm:inline-flex"
                            }, [
                              createVNode("i", { class: "fa-solid fa-chevron-down ml-1 text-xs" })
                            ])
                          ])
                        ];
                      }
                    }),
                    content: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_sfc_main$4, {
                          href: _ctx.route("category.show", 1),
                          as: "button"
                        }, {
                          default: withCtx((_3, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(` Lifestyle `);
                            } else {
                              return [
                                createTextVNode(" Lifestyle ")
                              ];
                            }
                          }),
                          _: 2
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(_sfc_main$4, {
                          href: _ctx.route("category.show", 2),
                          as: "button"
                        }, {
                          default: withCtx((_3, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(` Hiburan `);
                            } else {
                              return [
                                createTextVNode(" Hiburan ")
                              ];
                            }
                          }),
                          _: 2
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(_sfc_main$4, {
                          href: _ctx.route("category.show", 3),
                          as: "button"
                        }, {
                          default: withCtx((_3, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(` Teknologi `);
                            } else {
                              return [
                                createTextVNode(" Teknologi ")
                              ];
                            }
                          }),
                          _: 2
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(_sfc_main$4, {
                          href: _ctx.route("category.show", 4),
                          as: "button"
                        }, {
                          default: withCtx((_3, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(` Otomotif `);
                            } else {
                              return [
                                createTextVNode(" Otomotif ")
                              ];
                            }
                          }),
                          _: 2
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_sfc_main$4, {
                            href: _ctx.route("category.show", 1),
                            as: "button"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Lifestyle ")
                            ]),
                            _: 1
                          }, 8, ["href"]),
                          createVNode(_sfc_main$4, {
                            href: _ctx.route("category.show", 2),
                            as: "button"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Hiburan ")
                            ]),
                            _: 1
                          }, 8, ["href"]),
                          createVNode(_sfc_main$4, {
                            href: _ctx.route("category.show", 3),
                            as: "button"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Teknologi ")
                            ]),
                            _: 1
                          }, 8, ["href"]),
                          createVNode(_sfc_main$4, {
                            href: _ctx.route("category.show", 4),
                            as: "button"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Otomotif ")
                            ]),
                            _: 1
                          }, 8, ["href"])
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                  _push3(`</div>`);
                  _push3(ssrRenderComponent(unref(DisclosureButton), {
                    key: "forum",
                    as: "a",
                    href: _ctx.route("all-forum.allforum"),
                    class: "px-7 py-2 rounded-md text-sm font-medium hover:font-bold"
                  }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`Forum`);
                      } else {
                        return [
                          createTextVNode("Forum")
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(unref(DisclosureButton), {
                    key: "video",
                    as: "a",
                    href: _ctx.route("all-video.allvideo"),
                    class: "px-7 py-2 rounded-md text-sm font-medium hover:font-bold"
                  }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`Video`);
                      } else {
                        return [
                          createTextVNode("Video")
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(unref(DisclosureButton), {
                    key: "about",
                    as: "a",
                    class: "px-7 py-2 rounded-md text-sm font-medium hover:font-bold"
                  }, {
                    default: withCtx((_2, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`About`);
                      } else {
                        return [
                          createTextVNode("About")
                        ];
                      }
                    }),
                    _: 2
                  }, _parent3, _scopeId2));
                  _push3(`</div></div>`);
                } else {
                  return [
                    createVNode("div", { class: "space-y-1 px-2 pt-2 pb-3" }, [
                      createVNode("div", { class: "flex" }, [
                        createVNode(unref(DisclosureButton), {
                          key: "article",
                          as: "a",
                          href: _ctx.route("all-article.allarticle"),
                          class: "pl-7 py-2 rounded-md text-sm font-medium hover:font-bold"
                        }, {
                          default: withCtx(() => [
                            createTextVNode("Article")
                          ]),
                          _: 1
                        }, 8, ["href"]),
                        createVNode("div", { class: "relative" }, [
                          createVNode(_sfc_main$3, {
                            align: "left",
                            width: "48"
                          }, {
                            trigger: withCtx(() => [
                              createVNode("span", { class: "inline-flex rounded-md" }, [
                                createVNode("button", {
                                  type: "button",
                                  class: "inline-flex items-center justify-center mt-3 mr-7 font-medium hover:font-bold text-sm normal-case hover:text-white transition duration-150 ease-in-out sm:hidden"
                                }, [
                                  createVNode("i", { class: "fa-solid fa-chevron-down ml-1 text-xs" })
                                ]),
                                createVNode("button", {
                                  type: "button",
                                  class: "items-center justify-center mt-3 mr-7 font-medium hover:font-black text-sm normal-case transition duration-150 ease-in-out hidden sm:inline-flex"
                                }, [
                                  createVNode("i", { class: "fa-solid fa-chevron-down ml-1 text-xs" })
                                ])
                              ])
                            ]),
                            content: withCtx(() => [
                              createVNode(_sfc_main$4, {
                                href: _ctx.route("category.show", 1),
                                as: "button"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(" Lifestyle ")
                                ]),
                                _: 1
                              }, 8, ["href"]),
                              createVNode(_sfc_main$4, {
                                href: _ctx.route("category.show", 2),
                                as: "button"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(" Hiburan ")
                                ]),
                                _: 1
                              }, 8, ["href"]),
                              createVNode(_sfc_main$4, {
                                href: _ctx.route("category.show", 3),
                                as: "button"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(" Teknologi ")
                                ]),
                                _: 1
                              }, 8, ["href"]),
                              createVNode(_sfc_main$4, {
                                href: _ctx.route("category.show", 4),
                                as: "button"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(" Otomotif ")
                                ]),
                                _: 1
                              }, 8, ["href"])
                            ]),
                            _: 1
                          })
                        ]),
                        createVNode(unref(DisclosureButton), {
                          key: "forum",
                          as: "a",
                          href: _ctx.route("all-forum.allforum"),
                          class: "px-7 py-2 rounded-md text-sm font-medium hover:font-bold"
                        }, {
                          default: withCtx(() => [
                            createTextVNode("Forum")
                          ]),
                          _: 1
                        }, 8, ["href"]),
                        createVNode(unref(DisclosureButton), {
                          key: "video",
                          as: "a",
                          href: _ctx.route("all-video.allvideo"),
                          class: "px-7 py-2 rounded-md text-sm font-medium hover:font-bold"
                        }, {
                          default: withCtx(() => [
                            createTextVNode("Video")
                          ]),
                          _: 1
                        }, 8, ["href"]),
                        createVNode(unref(DisclosureButton), {
                          key: "about",
                          as: "a",
                          class: "px-7 py-2 rounded-md text-sm font-medium hover:font-bold"
                        }, {
                          default: withCtx(() => [
                            createTextVNode("About")
                          ]),
                          _: 1
                        })
                      ])
                    ])
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode("div", { class: "mx-auto max-w-7xl px-2 sm:px-6 lg:px-8" }, [
                createVNode("div", { class: "relative flex h-16 items-center justify-between" }, [
                  createVNode("div", { class: "absolute inset-y-0 left-0 flex items-center sm:hidden" }, [
                    createVNode(unref(DisclosureButton), { class: "inline-flex items-center justify-center rounded-md p-2 text-gray-400 hover:bg-gray-700 hover:text-white focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white" }, {
                      default: withCtx(() => [
                        createVNode("span", { class: "sr-only" }, "Open main menu"),
                        !open ? (openBlock(), createBlock(unref(Bars3Icon), {
                          key: 0,
                          class: "block h-6 w-6",
                          "aria-hidden": "true"
                        })) : (openBlock(), createBlock(unref(XMarkIcon), {
                          key: 1,
                          class: "block h-6 w-6",
                          "aria-hidden": "true"
                        }))
                      ]),
                      _: 2
                    }, 1024)
                  ]),
                  createVNode("div", { class: "flex flex-1 items-center justify-center sm:items-stretch sm:justify-start" }, [
                    createVNode("div", { class: "flex flex-shrink-0 items-center mr-16" }, [
                      createVNode("img", {
                        class: "block h-12 w-auto lg:hidden",
                        src: _imports_0,
                        alt: "Logo ENT"
                      }),
                      createVNode("img", {
                        class: "hidden h-12 w-auto lg:block",
                        src: _imports_0,
                        alt: "Logo ENT"
                      })
                    ]),
                    createVNode("div", { class: "hidden sm:ml-6 sm:block mt-1" }, [
                      createVNode("div", { class: "flex" }, [
                        createVNode(unref(Link), {
                          key: "article",
                          href: _ctx.route("all-article.allarticle"),
                          class: "pl-3 py-2 rounded-md text-sm font-medium hover:font-bold"
                        }, {
                          default: withCtx(() => [
                            createTextVNode("Article")
                          ]),
                          _: 1
                        }, 8, ["href"]),
                        createVNode("div", { class: "relative" }, [
                          createVNode(_sfc_main$3, {
                            align: "left",
                            width: "48"
                          }, {
                            trigger: withCtx(() => [
                              createVNode("span", { class: "inline-flex rounded-md" }, [
                                createVNode("button", {
                                  type: "button",
                                  class: "inline-flex items-center justify-center p-2 rounded-md transition duration-150 ease-in-out sm:hidden"
                                }, [
                                  createVNode(unref(UserIcon), { class: "h-4 w-4" })
                                ]),
                                createVNode("button", {
                                  type: "button",
                                  class: "items-center justify-center mt-3 mr-7 font-medium hover:font-black text-sm normal-case transition duration-150 ease-in-out hidden sm:inline-flex"
                                }, [
                                  createVNode("i", { class: "fa-solid fa-chevron-down ml-1 text-xs" })
                                ])
                              ])
                            ]),
                            content: withCtx(() => [
                              createVNode(_sfc_main$4, {
                                href: _ctx.route("category.show", 1),
                                as: "button"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(" Lifestyle ")
                                ]),
                                _: 1
                              }, 8, ["href"]),
                              createVNode(_sfc_main$4, {
                                href: _ctx.route("category.show", 2),
                                as: "button"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(" Hiburan ")
                                ]),
                                _: 1
                              }, 8, ["href"]),
                              createVNode(_sfc_main$4, {
                                href: _ctx.route("category.show", 3),
                                as: "button"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(" Teknologi ")
                                ]),
                                _: 1
                              }, 8, ["href"]),
                              createVNode(_sfc_main$4, {
                                href: _ctx.route("category.show", 4),
                                as: "button"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(" Otomotif ")
                                ]),
                                _: 1
                              }, 8, ["href"])
                            ]),
                            _: 1
                          })
                        ]),
                        createVNode(unref(Link), {
                          key: "forum",
                          href: _ctx.route("all-forum.allforum"),
                          class: "px-7 py-2 rounded-md text-sm font-medium hover:font-bold"
                        }, {
                          default: withCtx(() => [
                            createTextVNode("Forum")
                          ]),
                          _: 1
                        }, 8, ["href"]),
                        createVNode(unref(Link), {
                          key: "video",
                          href: _ctx.route("all-video.allvideo"),
                          class: "px-7 py-2 rounded-md text-sm font-medium hover:font-bold"
                        }, {
                          default: withCtx(() => [
                            createTextVNode("Video")
                          ]),
                          _: 1
                        }, 8, ["href"]),
                        createVNode(unref(Link), {
                          key: "about",
                          class: "px-7 py-2 rounded-md text-sm font-medium hover:font-bold"
                        }, {
                          default: withCtx(() => [
                            createTextVNode("About")
                          ]),
                          _: 1
                        })
                      ])
                    ])
                  ]),
                  _ctx.$page.props.auth.user != null ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "flex"
                  }, [
                    _ctx.$page.props.auth.user.name == "Superadmin" ? (openBlock(), createBlock("div", { key: 0 }, [
                      createVNode(unref(Link), {
                        class: "bg-sky-900 rounded-full px-4 py-1 my-auto font-medium hover:font-bold hover:bg-yellow-700 text-sm normal-case text-white",
                        href: "/dashboard"
                      }, {
                        default: withCtx(() => [
                          createTextVNode("Dashboard")
                        ]),
                        _: 1
                      })
                    ])) : createCommentVNode("", true),
                    createVNode("div", { class: "relative" }, [
                      createVNode(_sfc_main$3, {
                        align: "right",
                        width: "48"
                      }, {
                        trigger: withCtx(() => [
                          createVNode("span", { class: "inline-flex rounded-md" }, [
                            createVNode("button", {
                              type: "button",
                              class: "inline-flex items-center justify-center p-2 rounded-md transition duration-150 ease-in-out sm:hidden"
                            }, [
                              createVNode(unref(UserIcon), { class: "h-4 w-4" })
                            ]),
                            createVNode("button", {
                              type: "button",
                              class: "ml-4 items-center justify-center bg-sky-300 rounded-full px-4 py-1 my-auto font-medium hover:font-bold hover:bg-yellow-700 text-sm normal-case text-sky-900 hover:text-white transition duration-150 ease-in-out hidden sm:inline-flex"
                            }, [
                              createVNode("span", { class: "flex justify-between items-center capitalize" }, toDisplayString(_ctx.$page.props.auth.user.name.split(" ")[0]), 1),
                              createVNode("i", { class: "fa-solid fa-chevron-down ml-1 text-xs" })
                            ])
                          ])
                        ]),
                        content: withCtx(() => [
                          createVNode(_sfc_main$4, {
                            href: _ctx.route("logout"),
                            method: "post",
                            as: "button"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(toDisplayString(_ctx.lang().label.logout), 1)
                            ]),
                            _: 1
                          }, 8, ["href"])
                        ]),
                        _: 1
                      })
                    ])
                  ])) : (openBlock(), createBlock("div", { key: 1 }, [
                    createVNode(unref(Link), {
                      class: "bg-sky-900 rounded-full px-4 py-1 my-auto font-medium hover:font-bold hover:bg-yellow-700 text-sm normal-case text-white",
                      href: "/login"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Login")
                      ]),
                      _: 1
                    })
                  ]))
                ])
              ]),
              createVNode(unref(DisclosurePanel), { class: "sm:hidden" }, {
                default: withCtx(() => [
                  createVNode("div", { class: "space-y-1 px-2 pt-2 pb-3" }, [
                    createVNode("div", { class: "flex" }, [
                      createVNode(unref(DisclosureButton), {
                        key: "article",
                        as: "a",
                        href: _ctx.route("all-article.allarticle"),
                        class: "pl-7 py-2 rounded-md text-sm font-medium hover:font-bold"
                      }, {
                        default: withCtx(() => [
                          createTextVNode("Article")
                        ]),
                        _: 1
                      }, 8, ["href"]),
                      createVNode("div", { class: "relative" }, [
                        createVNode(_sfc_main$3, {
                          align: "left",
                          width: "48"
                        }, {
                          trigger: withCtx(() => [
                            createVNode("span", { class: "inline-flex rounded-md" }, [
                              createVNode("button", {
                                type: "button",
                                class: "inline-flex items-center justify-center mt-3 mr-7 font-medium hover:font-bold text-sm normal-case hover:text-white transition duration-150 ease-in-out sm:hidden"
                              }, [
                                createVNode("i", { class: "fa-solid fa-chevron-down ml-1 text-xs" })
                              ]),
                              createVNode("button", {
                                type: "button",
                                class: "items-center justify-center mt-3 mr-7 font-medium hover:font-black text-sm normal-case transition duration-150 ease-in-out hidden sm:inline-flex"
                              }, [
                                createVNode("i", { class: "fa-solid fa-chevron-down ml-1 text-xs" })
                              ])
                            ])
                          ]),
                          content: withCtx(() => [
                            createVNode(_sfc_main$4, {
                              href: _ctx.route("category.show", 1),
                              as: "button"
                            }, {
                              default: withCtx(() => [
                                createTextVNode(" Lifestyle ")
                              ]),
                              _: 1
                            }, 8, ["href"]),
                            createVNode(_sfc_main$4, {
                              href: _ctx.route("category.show", 2),
                              as: "button"
                            }, {
                              default: withCtx(() => [
                                createTextVNode(" Hiburan ")
                              ]),
                              _: 1
                            }, 8, ["href"]),
                            createVNode(_sfc_main$4, {
                              href: _ctx.route("category.show", 3),
                              as: "button"
                            }, {
                              default: withCtx(() => [
                                createTextVNode(" Teknologi ")
                              ]),
                              _: 1
                            }, 8, ["href"]),
                            createVNode(_sfc_main$4, {
                              href: _ctx.route("category.show", 4),
                              as: "button"
                            }, {
                              default: withCtx(() => [
                                createTextVNode(" Otomotif ")
                              ]),
                              _: 1
                            }, 8, ["href"])
                          ]),
                          _: 1
                        })
                      ]),
                      createVNode(unref(DisclosureButton), {
                        key: "forum",
                        as: "a",
                        href: _ctx.route("all-forum.allforum"),
                        class: "px-7 py-2 rounded-md text-sm font-medium hover:font-bold"
                      }, {
                        default: withCtx(() => [
                          createTextVNode("Forum")
                        ]),
                        _: 1
                      }, 8, ["href"]),
                      createVNode(unref(DisclosureButton), {
                        key: "video",
                        as: "a",
                        href: _ctx.route("all-video.allvideo"),
                        class: "px-7 py-2 rounded-md text-sm font-medium hover:font-bold"
                      }, {
                        default: withCtx(() => [
                          createTextVNode("Video")
                        ]),
                        _: 1
                      }, 8, ["href"]),
                      createVNode(unref(DisclosureButton), {
                        key: "about",
                        as: "a",
                        class: "px-7 py-2 rounded-md text-sm font-medium hover:font-bold"
                      }, {
                        default: withCtx(() => [
                          createTextVNode("About")
                        ]),
                        _: 1
                      })
                    ])
                  ])
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/NavbarUser.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  _push(`<footer${ssrRenderAttrs(mergeProps({ class: "px-4 pb-4 bg-slate-50 md:px-6 md:pb-8 dark:bg-gray-900" }, _attrs))}><div class="sm:flex mx-auto max-w-7xl sm:items-center sm:justify-between"><div><a class="flex items-center mb-4 sm:mb-0"><img${ssrRenderAttr("src", _imports_0)} class="h-52 pt-6 bg-sky-100 rounded-b-xl p-2" alt="Logo ENT"></a></div><div class="md:text-center"><div class="content-center text-gray-500 dark:text-gray-400"><a href="all-article" class="hover:font-black mr-4 md:mx-4 font-bold text-sm">Article</a><a href="all-forum" class="hover:font-black font-bold mx-4 text-sm">Forum</a><a href="all-video" class="hover:font-black font-bold mx-4 text-sm">Video</a><a href="#about" class="hover:font-black font-bold mx-4 text-sm hover:">About</a></div><a href="https://www.facebook.com"><i class="fa-brands fa-facebook-f text-xl hover:text-yellow-700 text-slate-400 mx-3 md:mt-8 sm:mt-1"></i></a><a href="https://www.instagram.com/entcrews" target="_blank"><i class="fa-brands fa-instagram text-xl hover:text-yellow-700 text-slate-400 mt-4 mx-3"></i></a><a href="mailto: ent@gmail.com" target="_blank"><i class="fa-solid fa-envelope text-xl hover:text-yellow-700 text-slate-400 mx-3"></i></a><a href="https://www.twitter.com/entcrews" target="_blank"><i class="fa-brands fa-twitter text-xl hover:text-yellow-700 text-slate-400 mx-3"></i></a><a href="https://www.youtube.com/@entcrews" target="_Blank"><i class="fa-brands fa-youtube text-xl hover:text-yellow-700 text-slate-400 mx-3"></i></a><br><span class="mt-4 text-xs font-bold text-slate-400">@ 2023 EEPIS News and Network Team</span></div><div><h2 class="my-2 font-semibold text-md">Location</h2><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3957.691977074115!2d112.79156701477496!3d-7.2758470947483636!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd7fa10ea2ae883%3A0xbe22c55d60ef09c7!2sPoliteknik%20Elektronika%20Negeri%20Surabaya!5e0!3m2!1sid!2sid!4v1675351583121!5m2!1sid!2sid" width="300" height="168" style="${ssrRenderStyle({ "border": "0" })}" allowfullscreen="" loading="lazy" class="rounded-xl" referrerpolicy="no-referrer-when-downgrade"></iframe></div></div></footer>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/FooterUser.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const FooterUser = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender]]);
const HomeLayout_vue_vue_type_style_index_0_lang = "";
const _sfc_main = {
  __name: "HomeLayout",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-full" }, _attrs))}>`);
      _push(ssrRenderComponent(_sfc_main$2, null, null, _parent));
      _push(`<main>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</main>`);
      _push(ssrRenderComponent(FooterUser, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Layouts/HomeLayout.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as _
};
