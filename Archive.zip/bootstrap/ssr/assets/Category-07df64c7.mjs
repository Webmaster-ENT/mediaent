import { withCtx, unref, createTextVNode, createVNode, openBlock, createBlock, Fragment, renderList, toDisplayString, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrRenderAttr, ssrInterpolate } from "vue/server-renderer";
import { Link } from "@inertiajs/inertia-vue3";
import { _ as _sfc_main$1 } from "./HomeLayout-6d6c8674.mjs";
import "@heroicons/vue/24/solid";
import "@headlessui/vue";
import "@heroicons/vue/24/outline";
import "./DropdownLink-8164274e.mjs";
import "./_plugin-vue_export-helper-cc2b3d55.mjs";
const _sfc_main = {
  __name: "Category",
  __ssrInlineRender: true,
  props: {
    articles: Object
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$1, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="bg-sky-900"${_scopeId}><div class="max-w-xs mx-auto overflow-hidden md:max-w-5xl lg:max-w-7xl"${_scopeId}><br${_scopeId}><br${_scopeId}><br${_scopeId}><div class="container mx-auto my-auto px-6 pb-12 sm:flex sm:flex-wrap sm:gap-6 sm:justify-center"${_scopeId}><!--[-->`);
            ssrRenderList(__props.articles, (article) => {
              _push2(`<div${_scopeId}><div class="p-4 rounded-2xl shadow-lg overflow-hidden mb-10 bg-white sm:mb-0 sm:w-64 md:w-80 lg:w-72 xl:w-96"${_scopeId}><img class="rounded-2xl w-full"${ssrRenderAttr("src", "../" + article.thumbnail)} alt=""${_scopeId}><div class="inline-block text-xs font-normal mt-4 text-white bg-sky-900 py-1 px-2 rounded-3xl w-auto flex-none"${_scopeId}>${ssrInterpolate(article.category.name)}</div><div class="mt-3 text-sm font-bold h-14"${_scopeId}><p${_scopeId}>${ssrInterpolate(article.title)}</p></div><div class="text-xs font-medium opacity-80 mt-3"${_scopeId}><span${_scopeId}>${article.summary}</span></div><div class="pt-3 float-right inline-block text-xs font-semibold text-sky-900 w-auto"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(Link), {
                href: _ctx.route("detail-article.showArticle", article.slug)
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`Readmore`);
                  } else {
                    return [
                      createTextVNode("Readmore")
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              _push2(`</div></div><br${_scopeId}></div>`);
            });
            _push2(`<!--]--></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "bg-sky-900" }, [
                createVNode("div", { class: "max-w-xs mx-auto overflow-hidden md:max-w-5xl lg:max-w-7xl" }, [
                  createVNode("br"),
                  createVNode("br"),
                  createVNode("br"),
                  createVNode("div", { class: "container mx-auto my-auto px-6 pb-12 sm:flex sm:flex-wrap sm:gap-6 sm:justify-center" }, [
                    (openBlock(true), createBlock(Fragment, null, renderList(__props.articles, (article) => {
                      return openBlock(), createBlock("div", {
                        key: article.id
                      }, [
                        createVNode("div", { class: "p-4 rounded-2xl shadow-lg overflow-hidden mb-10 bg-white sm:mb-0 sm:w-64 md:w-80 lg:w-72 xl:w-96" }, [
                          createVNode("img", {
                            class: "rounded-2xl w-full",
                            src: "../" + article.thumbnail,
                            alt: ""
                          }, null, 8, ["src"]),
                          createVNode("div", { class: "inline-block text-xs font-normal mt-4 text-white bg-sky-900 py-1 px-2 rounded-3xl w-auto flex-none" }, toDisplayString(article.category.name), 1),
                          createVNode("div", { class: "mt-3 text-sm font-bold h-14" }, [
                            createVNode("p", null, toDisplayString(article.title), 1)
                          ]),
                          createVNode("div", { class: "text-xs font-medium opacity-80 mt-3" }, [
                            createVNode("span", {
                              innerHTML: article.summary
                            }, null, 8, ["innerHTML"])
                          ]),
                          createVNode("div", { class: "pt-3 float-right inline-block text-xs font-semibold text-sky-900 w-auto" }, [
                            createVNode(unref(Link), {
                              href: _ctx.route("detail-article.showArticle", article.slug)
                            }, {
                              default: withCtx(() => [
                                createTextVNode("Readmore")
                              ]),
                              _: 2
                            }, 1032, ["href"])
                          ])
                        ]),
                        createVNode("br")
                      ]);
                    }), 128))
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/FrontEnd/Category.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
