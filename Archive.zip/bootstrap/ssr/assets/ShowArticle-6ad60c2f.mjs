import { unref, withCtx, createVNode, createTextVNode, toDisplayString, openBlock, createBlock, Fragment, renderList, withModifiers, withDirectives, vShow, createCommentVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrInterpolate, ssrRenderAttr, ssrRenderStyle } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./HomeLayout-6d6c8674.mjs";
import { useForm, Head, Link } from "@inertiajs/inertia-vue3";
import { _ as _sfc_main$2 } from "./TextInput-a82a0582.mjs";
import { HandThumbUpIcon, ChatBubbleLeftEllipsisIcon, UserCircleIcon, TrashIcon, PaperAirplaneIcon } from "@heroicons/vue/24/solid";
import "@headlessui/vue";
import "@heroicons/vue/24/outline";
import "./DropdownLink-8164274e.mjs";
import "./_plugin-vue_export-helper-cc2b3d55.mjs";
const ShowArticle_vue_vue_type_style_index_0_setup_true_lang = "";
const _sfc_main = {
  __name: "ShowArticle",
  __ssrInlineRender: true,
  props: {
    articles: Object,
    previous: Object,
    next: Object,
    articleid: Number,
    userid: Number
  },
  setup(__props) {
    const props = __props;
    const form = useForm({
      id: props.articles.id,
      comment: "",
      like: props.articles.like,
      _method: "put"
    });
    function deleteLike(id) {
      form.delete(route("article.delete-like", id));
    }
    const likeadd = () => {
      form.post(route("article.create-like", props.articleid));
    };
    function deleteComment(id) {
      form.delete(route("article.delete-comment", id));
    }
    const commentadd = () => {
      form.post(route("article.create-comment", props.articleid));
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Article" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="pt-5"${_scopeId}><div class="mx-auto max-w-7xl sm:px-6 px-4 lg:px-8"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: _ctx.route("all-article.allarticle")
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="flex items-center pt-2 md:text-lg text-xs"${_scopeId2}><i class="fa-solid fa-chevron-left mr-1"${_scopeId2}></i><span class="font-bold"${_scopeId2}>Back to Article</span></div>`);
                } else {
                  return [
                    createVNode("div", { class: "flex items-center pt-2 md:text-lg text-xs" }, [
                      createVNode("i", { class: "fa-solid fa-chevron-left mr-1" }),
                      createVNode("span", { class: "font-bold" }, "Back to Article")
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div><div class="mx-auto max-w-8xl sm:px-6 lg:px-8"${_scopeId}><!--[-->`);
            ssrRenderList(__props.articles, (article) => {
              _push2(`<div class="container mx-auto pt-4"${_scopeId}><section class="text-gray-500 bg-white rounded-lg"${_scopeId}><div class="flex flex-wrap justify-center"${_scopeId}><h1 class="font-bold md:w-1/2 md:text-6xl text-3xl text-center text-gray-900 mb-4"${_scopeId}>${ssrInterpolate(article.title)}</h1><div class="w-50 md:w-3/4"${_scopeId}><p class="md:text-xl text-sm text-center capitalize"${_scopeId}>${ssrInterpolate(article.updated_at)} | ${ssrInterpolate(article.user.name)}</p><div class="text-center my-4"${_scopeId}><button class="inline-flex items-center md:px-4 px-3 md:py-2 py-1 bg-blue-600 border border-transparent rounded-full font-semibold md:text-xs text-xs text-white uppercase tracking-widest hover:bg-blue-500 active:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 dark:focus:ring-offset-gray-800 transition ease-in-out duration-150" disabled${_scopeId}>${ssrInterpolate(article.category.name)}</button></div><div class="relative overflow-hidden bg-no-repeat bg-cover relative overflow-hidden bg-no-repeat bg-cover ripple md:my-4 my-2 px-5"${_scopeId}><img${ssrRenderAttr("src", "../../" + article.thumbnail)} class="w-full rounded-3xl mt-4"${_scopeId}></div><div class="md:my-10 mt-10 prose lg:prose-xl md:max-w-4xl md:px-6 px-12 mx-auto" style="${ssrRenderStyle({ "text-align": "justify" })}"${_scopeId}><span class="md:text-xl text-sm"${_scopeId}>${article.body}</span></div><div class="md:mt-6 px-6"${_scopeId}><div class="flex md:mb-12 my-4 text-black items-center text-sm md:text-xl"${_scopeId}>`);
              if (__props.userid != null) {
                _push2(`<div${_scopeId}>`);
                if (article.likes_user == "") {
                  _push2(`<div${_scopeId}><form${_scopeId}><button type="submit"${_scopeId}>`);
                  _push2(ssrRenderComponent(unref(HandThumbUpIcon), { class: "w-4 h-4 mt-1 md:w-5 md:h-5 lg:w-6 lg:h-6" }, null, _parent2, _scopeId));
                  _push2(`</button></form></div>`);
                } else {
                  _push2(`<div${_scopeId}><!--[-->`);
                  ssrRenderList(article.likes_user, (like) => {
                    _push2(`<!--[--><div style="${ssrRenderStyle(like.user_id == __props.userid ? null : { display: "none" })}"${_scopeId}><button tabindex="-1" type="button" class="mt-1"${_scopeId}>`);
                    _push2(ssrRenderComponent(unref(HandThumbUpIcon), { class: "w-4 h-4 text-yellow-700 md:w-5 md:h-5 lg:w-6 lg:h-6" }, null, _parent2, _scopeId));
                    _push2(`</button></div><div style="${ssrRenderStyle(like.user_id != __props.userid ? null : { display: "none" })}"${_scopeId}><form${_scopeId}><div className="mt-4"${_scopeId}><button type="submit"${_scopeId}>`);
                    _push2(ssrRenderComponent(unref(HandThumbUpIcon), { class: "w-4 h-4 mt-1 md:w-5 md:h-5 lg:w-6 lg:h-6" }, null, _parent2, _scopeId));
                    _push2(`</button></div></form></div><!--]-->`);
                  });
                  _push2(`<!--]--></div>`);
                }
                _push2(`</div>`);
              } else {
                _push2(`<div${_scopeId}>`);
                _push2(ssrRenderComponent(unref(HandThumbUpIcon), { class: "w-4 h-4 md:w-5 md:h-5 lg:w-6 lg:h-6" }, null, _parent2, _scopeId));
                _push2(`</div>`);
              }
              _push2(`<span class="mx-2 md:mr-6 mr-4 font-medium text-md"${_scopeId}>${ssrInterpolate(article.likes.length)}</span>`);
              _push2(ssrRenderComponent(unref(ChatBubbleLeftEllipsisIcon), { class: "w-4 h-4 md:w-5 md:h-5 lg:w-6 lg:h-6" }, null, _parent2, _scopeId));
              _push2(`<span class="mx-2 font-medium text-md"${_scopeId}>${ssrInterpolate(article.comments.length)}</span></div></div><div class="grid grid-cols-2 px-6"${_scopeId}><div${_scopeId}>`);
              if (__props.previous != null) {
                _push2(`<div${_scopeId}>`);
                _push2(ssrRenderComponent(unref(Link), {
                  href: _ctx.route("detail-article.showArticle", __props.previous.slug)
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(`<div class="text-md font-bold text-slate-900"${_scopeId2}><i class="fa-solid fa-chevron-left"${_scopeId2}></i> PREVIOUS </div><span class="uppercase hover:font-bold"${_scopeId2}>${ssrInterpolate(__props.previous.title)}</span>`);
                    } else {
                      return [
                        createVNode("div", { class: "text-md font-bold text-slate-900" }, [
                          createVNode("i", { class: "fa-solid fa-chevron-left" }),
                          createTextVNode(" PREVIOUS ")
                        ]),
                        createVNode("span", { class: "uppercase hover:font-bold" }, toDisplayString(__props.previous.title), 1)
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
                _push2(`</div>`);
              } else {
                _push2(`<div class="text-left"${_scopeId}><span class="text-md font-bold text-slate-900"${_scopeId}>This First Article</span></div>`);
              }
              _push2(`</div><div${_scopeId}>`);
              if (__props.next != null) {
                _push2(`<div class="flex text-right"${_scopeId}>`);
                _push2(ssrRenderComponent(unref(Link), {
                  href: _ctx.route("detail-article.showArticle", __props.next.slug)
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(`<div class="text-md font-semibold text-slate-900 hover:font-black"${_scopeId2}> NEXT <i class="fa-solid fa-chevron-right"${_scopeId2}></i></div><span class="uppercase hover:font-bold"${_scopeId2}>${ssrInterpolate(__props.next.title)}</span>`);
                    } else {
                      return [
                        createVNode("div", { class: "text-md font-semibold text-slate-900 hover:font-black" }, [
                          createTextVNode(" NEXT "),
                          createVNode("i", { class: "fa-solid fa-chevron-right" })
                        ]),
                        createVNode("span", { class: "uppercase hover:font-bold" }, toDisplayString(__props.next.title), 1)
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
                _push2(`</div>`);
              } else {
                _push2(`<div class="text-right"${_scopeId}><span class="text-md font-bold text-slate-900"${_scopeId}>This Last Article</span></div>`);
              }
              _push2(`</div></div><br${_scopeId}><div class="mt-7 flex max-w-xs overflow-hidden mx-auto md:max-w-xl lg:max-w-3xl"${_scopeId}><a class="md:w-full w-3/4 mx-auto text-white md:py-2 h-full bg-sky-900 rounded-xl text-center" type="" href="#comment"${_scopeId}><b class="text-white"${_scopeId}>Add a Comment<i class="fa-solid fa-pen-to-square ml-4"${_scopeId}></i></b></a></div><br${_scopeId}><br${_scopeId}><!--[-->`);
              ssrRenderList(article.comments, (comment) => {
                _push2(`<div${_scopeId}><br${_scopeId}><hr class="mx-auto border-t-2 md:w-full w-10/12"${_scopeId}><br${_scopeId}>`);
                if (__props.userid != null) {
                  _push2(`<div${_scopeId}><div class="py-2 md:py-6 md:ml-24 px-6 lg:p-8"${_scopeId}><div class="flex"${_scopeId}><div class=""${_scopeId}>`);
                  _push2(ssrRenderComponent(unref(UserCircleIcon), { class: "text-sky-900 w-10 h-10 my-auto md:w-12 md:h-12 lg:w-14 lg:h-14" }, null, _parent2, _scopeId));
                  _push2(`</div><div${_scopeId}><div class="ml-3 uppercase tracking-wide text-xs text-black font-medium md:text-base lg:text-lg"${_scopeId}>${ssrInterpolate(comment.user.name)}</div><div class="flex justify-between"${_scopeId}><p class="flex ml-3 font-medium text-sm opacity-50"${_scopeId}> Commented On ${ssrInterpolate(comment.created_at)} WIB </p>`);
                  if (comment.user_id == _ctx.$page.props.auth.user.id) {
                    _push2(`<div${_scopeId}><button tabindex="-1" type="button" class="mx-4 my-auto"${_scopeId}>`);
                    _push2(ssrRenderComponent(unref(TrashIcon), { class: "w-4 h-4 md:w-4 md:h-4 lg:w-4 lg:h-4 text-rose-700" }, null, _parent2, _scopeId));
                    _push2(`</button></div>`);
                  } else {
                    _push2(`<!---->`);
                  }
                  _push2(`</div><div class="md:mt-4 mt-2 ml-3 text-black font-normal text-base md:text-xl lg:text-2xl"${_scopeId}>${comment.comment}</div></div></div></div></div>`);
                } else {
                  _push2(`<div${_scopeId}><div class="py-2 md:py-6 md:ml-24 px-6 lg:p-8"${_scopeId}><div class="flex"${_scopeId}><div class=""${_scopeId}>`);
                  _push2(ssrRenderComponent(unref(UserCircleIcon), { class: "text-sky-900 w-10 h-10 my-auto md:w-12 md:h-12 lg:w-14 lg:h-14" }, null, _parent2, _scopeId));
                  _push2(`</div><div${_scopeId}><div class="ml-3 uppercase tracking-wide text-xs text-black font-medium md:text-base lg:text-lg"${_scopeId}>${ssrInterpolate(comment.user.name)}</div><div class="flex justify-between"${_scopeId}><p class="flex ml-3 font-medium text-sm opacity-50"${_scopeId}> Commented On ${ssrInterpolate(comment.created_at)} WIB </p></div><div class="md:mt-4 mt-2 ml-3 text-black font-normal text-base md:text-xl lg:text-2xl"${_scopeId}>${comment.comment}</div></div></div></div></div>`);
                }
                _push2(`</div>`);
              });
              _push2(`<!--]--></div></div></section></div>`);
            });
            _push2(`<!--]-->`);
            if (__props.userid != null) {
              _push2(`<div id="comment"${_scopeId}><div class="lg:p-8 w-full"${_scopeId}><form${_scopeId}><div class="flex max-w-xs overflow-hidden mx-auto w-full md:max-w-xl lg:max-w-3xl"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(UserCircleIcon), { class: "text-sky-900 w-12 h-12 my-auto mr-2 md:w-14 md:h-14 lg:w-16 lg:h-16" }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_sfc_main$2, {
                id: "title",
                type: "text",
                placeholder: "Comment ..",
                class: "mt-4 mb-4 bg-sky-900 text-white block w-full placeholder:text-slate-100 placeholder:italic focus:border-sky-900 focus:ring-sky-900",
                modelValue: unref(form).comment,
                "onUpdate:modelValue": ($event) => unref(form).comment = $event
              }, null, _parent2, _scopeId));
              _push2(`<button type="submit"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(PaperAirplaneIcon), { class: "text-sky-900 w-8 h-8 my-auto ml-2" }, null, _parent2, _scopeId));
              _push2(`</button></div></form></div></div>`);
            } else {
              _push2(`<div id="comment"${_scopeId}><div class="lg:p-8 w-full"${_scopeId}><div class="flex max-w-xs overflow-hidden mx-auto w-full md:max-w-xl lg:max-w-3xl"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(UserCircleIcon), { class: "text-sky-900 w-12 h-12 my-auto mr-2 md:w-14 md:h-14 lg:w-16 lg:h-16" }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_sfc_main$2, {
                id: "title",
                type: "text",
                placeholder: "Login for comment ..",
                class: "mt-4 mb-4 bg-sky-900 text-white block w-full placeholder:text-slate-100 placeholder:italic focus:border-sky-900 focus:ring-sky-900",
                modelValue: unref(form).comment,
                "onUpdate:modelValue": ($event) => unref(form).comment = $event,
                disabled: ""
              }, null, _parent2, _scopeId));
              _push2(`<button${_scopeId}>`);
              _push2(ssrRenderComponent(unref(PaperAirplaneIcon), { class: "text-sky-900 w-8 h-8 my-auto ml-2" }, null, _parent2, _scopeId));
              _push2(`</button></div></div></div>`);
            }
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "pt-5" }, [
                createVNode("div", { class: "mx-auto max-w-7xl sm:px-6 px-4 lg:px-8" }, [
                  createVNode(unref(Link), {
                    href: _ctx.route("all-article.allarticle")
                  }, {
                    default: withCtx(() => [
                      createVNode("div", { class: "flex items-center pt-2 md:text-lg text-xs" }, [
                        createVNode("i", { class: "fa-solid fa-chevron-left mr-1" }),
                        createVNode("span", { class: "font-bold" }, "Back to Article")
                      ])
                    ]),
                    _: 1
                  }, 8, ["href"])
                ]),
                createVNode("div", { class: "mx-auto max-w-8xl sm:px-6 lg:px-8" }, [
                  (openBlock(true), createBlock(Fragment, null, renderList(__props.articles, (article) => {
                    return openBlock(), createBlock("div", {
                      class: "container mx-auto pt-4",
                      key: article.id
                    }, [
                      createVNode("section", { class: "text-gray-500 bg-white rounded-lg" }, [
                        createVNode("div", { class: "flex flex-wrap justify-center" }, [
                          createVNode("h1", { class: "font-bold md:w-1/2 md:text-6xl text-3xl text-center text-gray-900 mb-4" }, toDisplayString(article.title), 1),
                          createVNode("div", { class: "w-50 md:w-3/4" }, [
                            createVNode("p", { class: "md:text-xl text-sm text-center capitalize" }, toDisplayString(article.updated_at) + " | " + toDisplayString(article.user.name), 1),
                            createVNode("div", { class: "text-center my-4" }, [
                              createVNode("button", {
                                class: "inline-flex items-center md:px-4 px-3 md:py-2 py-1 bg-blue-600 border border-transparent rounded-full font-semibold md:text-xs text-xs text-white uppercase tracking-widest hover:bg-blue-500 active:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 dark:focus:ring-offset-gray-800 transition ease-in-out duration-150",
                                disabled: ""
                              }, toDisplayString(article.category.name), 1)
                            ]),
                            createVNode("div", { class: "relative overflow-hidden bg-no-repeat bg-cover relative overflow-hidden bg-no-repeat bg-cover ripple md:my-4 my-2 px-5" }, [
                              createVNode("img", {
                                src: "../../" + article.thumbnail,
                                class: "w-full rounded-3xl mt-4"
                              }, null, 8, ["src"])
                            ]),
                            createVNode("div", {
                              class: "md:my-10 mt-10 prose lg:prose-xl md:max-w-4xl md:px-6 px-12 mx-auto",
                              style: { "text-align": "justify" }
                            }, [
                              createVNode("span", {
                                innerHTML: article.body,
                                class: "md:text-xl text-sm"
                              }, null, 8, ["innerHTML"])
                            ]),
                            createVNode("div", { class: "md:mt-6 px-6" }, [
                              createVNode("div", { class: "flex md:mb-12 my-4 text-black items-center text-sm md:text-xl" }, [
                                __props.userid != null ? (openBlock(), createBlock("div", { key: 0 }, [
                                  article.likes_user == "" ? (openBlock(), createBlock("div", { key: 0 }, [
                                    createVNode("form", {
                                      onSubmit: withModifiers(likeadd, ["prevent"])
                                    }, [
                                      createVNode("button", { type: "submit" }, [
                                        createVNode(unref(HandThumbUpIcon), { class: "w-4 h-4 mt-1 md:w-5 md:h-5 lg:w-6 lg:h-6" })
                                      ])
                                    ], 40, ["onSubmit"])
                                  ])) : (openBlock(), createBlock("div", { key: 1 }, [
                                    (openBlock(true), createBlock(Fragment, null, renderList(article.likes_user, (like) => {
                                      return openBlock(), createBlock(Fragment, { key: like }, [
                                        withDirectives(createVNode("div", null, [
                                          createVNode("button", {
                                            onClick: ($event) => deleteLike(like.id),
                                            tabindex: "-1",
                                            type: "button",
                                            class: "mt-1"
                                          }, [
                                            createVNode(unref(HandThumbUpIcon), { class: "w-4 h-4 text-yellow-700 md:w-5 md:h-5 lg:w-6 lg:h-6" })
                                          ], 8, ["onClick"])
                                        ], 512), [
                                          [vShow, like.user_id == __props.userid]
                                        ]),
                                        withDirectives(createVNode("div", null, [
                                          createVNode("form", {
                                            onSubmit: withModifiers(likeadd, ["prevent"])
                                          }, [
                                            createVNode("div", { className: "mt-4" }, [
                                              createVNode("button", { type: "submit" }, [
                                                createVNode(unref(HandThumbUpIcon), { class: "w-4 h-4 mt-1 md:w-5 md:h-5 lg:w-6 lg:h-6" })
                                              ])
                                            ])
                                          ], 40, ["onSubmit"])
                                        ], 512), [
                                          [vShow, like.user_id != __props.userid]
                                        ])
                                      ], 64);
                                    }), 128))
                                  ]))
                                ])) : (openBlock(), createBlock("div", { key: 1 }, [
                                  createVNode(unref(HandThumbUpIcon), { class: "w-4 h-4 md:w-5 md:h-5 lg:w-6 lg:h-6" })
                                ])),
                                createVNode("span", { class: "mx-2 md:mr-6 mr-4 font-medium text-md" }, toDisplayString(article.likes.length), 1),
                                createVNode(unref(ChatBubbleLeftEllipsisIcon), { class: "w-4 h-4 md:w-5 md:h-5 lg:w-6 lg:h-6" }),
                                createVNode("span", { class: "mx-2 font-medium text-md" }, toDisplayString(article.comments.length), 1)
                              ])
                            ]),
                            createVNode("div", { class: "grid grid-cols-2 px-6" }, [
                              createVNode("div", null, [
                                __props.previous != null ? (openBlock(), createBlock("div", { key: 0 }, [
                                  createVNode(unref(Link), {
                                    href: _ctx.route("detail-article.showArticle", __props.previous.slug)
                                  }, {
                                    default: withCtx(() => [
                                      createVNode("div", { class: "text-md font-bold text-slate-900" }, [
                                        createVNode("i", { class: "fa-solid fa-chevron-left" }),
                                        createTextVNode(" PREVIOUS ")
                                      ]),
                                      createVNode("span", { class: "uppercase hover:font-bold" }, toDisplayString(__props.previous.title), 1)
                                    ]),
                                    _: 1
                                  }, 8, ["href"])
                                ])) : (openBlock(), createBlock("div", {
                                  key: 1,
                                  class: "text-left"
                                }, [
                                  createVNode("span", { class: "text-md font-bold text-slate-900" }, "This First Article")
                                ]))
                              ]),
                              createVNode("div", null, [
                                __props.next != null ? (openBlock(), createBlock("div", {
                                  key: 0,
                                  class: "flex text-right"
                                }, [
                                  createVNode(unref(Link), {
                                    href: _ctx.route("detail-article.showArticle", __props.next.slug)
                                  }, {
                                    default: withCtx(() => [
                                      createVNode("div", { class: "text-md font-semibold text-slate-900 hover:font-black" }, [
                                        createTextVNode(" NEXT "),
                                        createVNode("i", { class: "fa-solid fa-chevron-right" })
                                      ]),
                                      createVNode("span", { class: "uppercase hover:font-bold" }, toDisplayString(__props.next.title), 1)
                                    ]),
                                    _: 1
                                  }, 8, ["href"])
                                ])) : (openBlock(), createBlock("div", {
                                  key: 1,
                                  class: "text-right"
                                }, [
                                  createVNode("span", { class: "text-md font-bold text-slate-900" }, "This Last Article")
                                ]))
                              ])
                            ]),
                            createVNode("br"),
                            createVNode("div", { class: "mt-7 flex max-w-xs overflow-hidden mx-auto md:max-w-xl lg:max-w-3xl" }, [
                              createVNode("a", {
                                class: "md:w-full w-3/4 mx-auto text-white md:py-2 h-full bg-sky-900 rounded-xl text-center",
                                type: "",
                                href: "#comment"
                              }, [
                                createVNode("b", { class: "text-white" }, [
                                  createTextVNode("Add a Comment"),
                                  createVNode("i", { class: "fa-solid fa-pen-to-square ml-4" })
                                ])
                              ])
                            ]),
                            createVNode("br"),
                            createVNode("br"),
                            (openBlock(true), createBlock(Fragment, null, renderList(article.comments, (comment) => {
                              return openBlock(), createBlock("div", {
                                key: comment.id
                              }, [
                                createVNode("br"),
                                createVNode("hr", { class: "mx-auto border-t-2 md:w-full w-10/12" }),
                                createVNode("br"),
                                __props.userid != null ? (openBlock(), createBlock("div", { key: 0 }, [
                                  createVNode("div", { class: "py-2 md:py-6 md:ml-24 px-6 lg:p-8" }, [
                                    createVNode("div", { class: "flex" }, [
                                      createVNode("div", { class: "" }, [
                                        createVNode(unref(UserCircleIcon), { class: "text-sky-900 w-10 h-10 my-auto md:w-12 md:h-12 lg:w-14 lg:h-14" })
                                      ]),
                                      createVNode("div", null, [
                                        createVNode("div", { class: "ml-3 uppercase tracking-wide text-xs text-black font-medium md:text-base lg:text-lg" }, toDisplayString(comment.user.name), 1),
                                        createVNode("div", { class: "flex justify-between" }, [
                                          createVNode("p", { class: "flex ml-3 font-medium text-sm opacity-50" }, " Commented On " + toDisplayString(comment.created_at) + " WIB ", 1),
                                          comment.user_id == _ctx.$page.props.auth.user.id ? (openBlock(), createBlock("div", { key: 0 }, [
                                            createVNode("button", {
                                              onClick: ($event) => deleteComment(comment.id),
                                              tabindex: "-1",
                                              type: "button",
                                              class: "mx-4 my-auto"
                                            }, [
                                              createVNode(unref(TrashIcon), { class: "w-4 h-4 md:w-4 md:h-4 lg:w-4 lg:h-4 text-rose-700" })
                                            ], 8, ["onClick"])
                                          ])) : createCommentVNode("", true)
                                        ]),
                                        createVNode("div", {
                                          class: "md:mt-4 mt-2 ml-3 text-black font-normal text-base md:text-xl lg:text-2xl",
                                          innerHTML: comment.comment
                                        }, null, 8, ["innerHTML"])
                                      ])
                                    ])
                                  ])
                                ])) : (openBlock(), createBlock("div", { key: 1 }, [
                                  createVNode("div", { class: "py-2 md:py-6 md:ml-24 px-6 lg:p-8" }, [
                                    createVNode("div", { class: "flex" }, [
                                      createVNode("div", { class: "" }, [
                                        createVNode(unref(UserCircleIcon), { class: "text-sky-900 w-10 h-10 my-auto md:w-12 md:h-12 lg:w-14 lg:h-14" })
                                      ]),
                                      createVNode("div", null, [
                                        createVNode("div", { class: "ml-3 uppercase tracking-wide text-xs text-black font-medium md:text-base lg:text-lg" }, toDisplayString(comment.user.name), 1),
                                        createVNode("div", { class: "flex justify-between" }, [
                                          createVNode("p", { class: "flex ml-3 font-medium text-sm opacity-50" }, " Commented On " + toDisplayString(comment.created_at) + " WIB ", 1)
                                        ]),
                                        createVNode("div", {
                                          class: "md:mt-4 mt-2 ml-3 text-black font-normal text-base md:text-xl lg:text-2xl",
                                          innerHTML: comment.comment
                                        }, null, 8, ["innerHTML"])
                                      ])
                                    ])
                                  ])
                                ]))
                              ]);
                            }), 128))
                          ])
                        ])
                      ])
                    ]);
                  }), 128)),
                  __props.userid != null ? (openBlock(), createBlock("div", {
                    key: 0,
                    id: "comment"
                  }, [
                    createVNode("div", { class: "lg:p-8 w-full" }, [
                      createVNode("form", {
                        onSubmit: withModifiers(commentadd, ["prevent"])
                      }, [
                        createVNode("div", { class: "flex max-w-xs overflow-hidden mx-auto w-full md:max-w-xl lg:max-w-3xl" }, [
                          createVNode(unref(UserCircleIcon), { class: "text-sky-900 w-12 h-12 my-auto mr-2 md:w-14 md:h-14 lg:w-16 lg:h-16" }),
                          createVNode(_sfc_main$2, {
                            id: "title",
                            type: "text",
                            placeholder: "Comment ..",
                            class: "mt-4 mb-4 bg-sky-900 text-white block w-full placeholder:text-slate-100 placeholder:italic focus:border-sky-900 focus:ring-sky-900",
                            modelValue: unref(form).comment,
                            "onUpdate:modelValue": ($event) => unref(form).comment = $event
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode("button", { type: "submit" }, [
                            createVNode(unref(PaperAirplaneIcon), { class: "text-sky-900 w-8 h-8 my-auto ml-2" })
                          ])
                        ])
                      ], 40, ["onSubmit"])
                    ])
                  ])) : (openBlock(), createBlock("div", {
                    key: 1,
                    id: "comment"
                  }, [
                    createVNode("div", { class: "lg:p-8 w-full" }, [
                      createVNode("div", { class: "flex max-w-xs overflow-hidden mx-auto w-full md:max-w-xl lg:max-w-3xl" }, [
                        createVNode(unref(UserCircleIcon), { class: "text-sky-900 w-12 h-12 my-auto mr-2 md:w-14 md:h-14 lg:w-16 lg:h-16" }),
                        createVNode(_sfc_main$2, {
                          id: "title",
                          type: "text",
                          placeholder: "Login for comment ..",
                          class: "mt-4 mb-4 bg-sky-900 text-white block w-full placeholder:text-slate-100 placeholder:italic focus:border-sky-900 focus:ring-sky-900",
                          modelValue: unref(form).comment,
                          "onUpdate:modelValue": ($event) => unref(form).comment = $event,
                          disabled: ""
                        }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                        createVNode("button", null, [
                          createVNode(unref(PaperAirplaneIcon), { class: "text-sky-900 w-8 h-8 my-auto ml-2" })
                        ])
                      ])
                    ])
                  ]))
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/FrontEnd/ShowArticle.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
