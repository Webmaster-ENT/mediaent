import { mergeProps, unref, withCtx, createVNode, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderSlot } from "vue/server-renderer";
import { A as ApplicationLogo } from "./ApplicationLogo-0976b5e5.mjs";
import { Link } from "@inertiajs/inertia-vue3";
const _sfc_main = {
  __name: "GuestLayout",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "min-h-screen flex flex-col justify-center items-center pt-6 sm:pt-0 bg-gray-100 dark:bg-gray-900" }, _attrs))}><div class="flex justify-between items-center w-full sm:max-w-md text-gray-500 dark:text-gray-300">`);
      _push(ssrRenderComponent(unref(Link), {
        class: "flex items-center",
        href: "/"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(ApplicationLogo, { class: "w-8 h-8 fill-current" }, null, _parent2, _scopeId));
            _push2(`<p class="text-lg ml-2"${_scopeId}>Laravel Brive</p>`);
          } else {
            return [
              createVNode(ApplicationLogo, { class: "w-8 h-8 fill-current" }),
              createVNode("p", { class: "text-lg ml-2" }, "Laravel Brive")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div></div></div><div class="w-full sm:max-w-md mt-6 px-6 py-4 bg-white dark:bg-gray-800 shadow-md overflow-hidden sm:rounded-lg">`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Layouts/GuestLayout.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as _
};
