import { unref, withCtx, createVNode, toDisplayString, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate } from "vue/server-renderer";
import { _ as _sfc_main$1, a as _sfc_main$2 } from "./Breadcrumb-78e1679a.mjs";
import { ClipboardDocumentListIcon, ChevronRightIcon, ChatBubbleBottomCenterTextIcon, PlayIcon } from "@heroicons/vue/24/solid";
import { Head, Link } from "@inertiajs/inertia-vue3";
import "./ApplicationLogo-0976b5e5.mjs";
import "./_plugin-vue_export-helper-cc2b3d55.mjs";
import "./DropdownLink-8164274e.mjs";
import "@headlessui/vue";
const _sfc_main = {
  __name: "Dashboard",
  __ssrInlineRender: true,
  props: {
    // users: Number,
    // roles: Number,
    // permissions: Number,
    articles: Number,
    forums: Number,
    videos: Number
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Dashboard" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_sfc_main$2, {
              title: "Dashboard",
              breadcrumbs: []
            }, null, _parent2, _scopeId));
            _push2(`<div class="space-y-4"${_scopeId}><div class="text-white dark:text-gray-100 grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-2 sm:gap-4 overflow-hidden shadow-sm"${_scopeId}><div${_scopeId}><div class="rounded-t-none sm:rounded-t-lg px-4 py-6 flex justify-between bg-blue-600/70 dark:bg-blue-600/60 items-center overflow-hidden"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(unref(ClipboardDocumentListIcon), { class: "w-12 h-12" }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex justify-between items-center"${_scopeId}><p class="text-4xl mr-2 font-bold mb-2"${_scopeId}>${ssrInterpolate(props.articles)}</p><p class="text-md md:text-xl uppercase text-right"${_scopeId}> Article </p></div></div><div class="bg-blue-600 dark:bg-blue-600/50 rounded-b-none sm:rounded-b-lg p-2 overflow-hidden hover:bg-blue-600/90 dark:hover:bg-blue-600/40"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: _ctx.route("article.index"),
              class: "flex justify-between items-center"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<p${_scopeId2}>${ssrInterpolate(_ctx.lang().label.more)}</p>`);
                  _push3(ssrRenderComponent(unref(ChevronRightIcon), { class: "w-5 h-5" }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode("p", null, toDisplayString(_ctx.lang().label.more), 1),
                    createVNode(unref(ChevronRightIcon), { class: "w-5 h-5" })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div><div${_scopeId}><div class="rounded-t-none sm:rounded-t-lg px-4 py-6 flex justify-between bg-green-600/70 dark:bg-green-600/60 items-center overflow-hidden"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(unref(ChatBubbleBottomCenterTextIcon), { class: "w-12 h-12" }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex justify-between items-center"${_scopeId}><p class="text-4xl mr-2 font-bold mb-2"${_scopeId}>${ssrInterpolate(props.forums)}</p><p class="text-md md:text-xl uppercase text-right"${_scopeId}> Forum </p></div></div><div class="bg-green-600 dark:bg-green-600/50 rounded-b-none sm:rounded-b-lg p-2 overflow-hidden hover:bg-green-600/90 dark:hover:bg-green-600/40"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: _ctx.route("forum.index"),
              class: "flex justify-between items-center"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<p${_scopeId2}>${ssrInterpolate(_ctx.lang().label.more)}</p>`);
                  _push3(ssrRenderComponent(unref(ChevronRightIcon), { class: "w-5 h-5" }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode("p", null, toDisplayString(_ctx.lang().label.more), 1),
                    createVNode(unref(ChevronRightIcon), { class: "w-5 h-5" })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div><div${_scopeId}><div class="rounded-t-none sm:rounded-t-lg px-4 py-6 flex justify-between bg-amber-600/70 dark:bg-amber-600/60 items-center overflow-hidden"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(unref(PlayIcon), { class: "w-12 h-12" }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex justify-between items-center"${_scopeId}><p class="text-4xl mr-2 font-bold mb-2"${_scopeId}>${ssrInterpolate(props.videos)}</p><p class="text-md md:text-xl uppercase text-right"${_scopeId}> Video </p></div></div><div class="bg-amber-600 dark:bg-amber-600/50 rounded-b-none sm:rounded-b-lg p-2 overflow-hidden hover:bg-amber-600/90 dark:hover:bg-amber-600/40"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: _ctx.route("video.index"),
              class: "flex justify-between items-center"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<p${_scopeId2}>${ssrInterpolate(_ctx.lang().label.more)}</p>`);
                  _push3(ssrRenderComponent(unref(ChevronRightIcon), { class: "w-5 h-5" }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode("p", null, toDisplayString(_ctx.lang().label.more), 1),
                    createVNode(unref(ChevronRightIcon), { class: "w-5 h-5" })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div></div></div>`);
          } else {
            return [
              createVNode(_sfc_main$2, {
                title: "Dashboard",
                breadcrumbs: []
              }),
              createVNode("div", { class: "space-y-4" }, [
                createVNode("div", { class: "text-white dark:text-gray-100 grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-2 sm:gap-4 overflow-hidden shadow-sm" }, [
                  createVNode("div", null, [
                    createVNode("div", { class: "rounded-t-none sm:rounded-t-lg px-4 py-6 flex justify-between bg-blue-600/70 dark:bg-blue-600/60 items-center overflow-hidden" }, [
                      createVNode("div", null, [
                        createVNode(unref(ClipboardDocumentListIcon), { class: "w-12 h-12" })
                      ]),
                      createVNode("div", { class: "flex justify-between items-center" }, [
                        createVNode("p", { class: "text-4xl mr-2 font-bold mb-2" }, toDisplayString(props.articles), 1),
                        createVNode("p", { class: "text-md md:text-xl uppercase text-right" }, " Article ")
                      ])
                    ]),
                    createVNode("div", { class: "bg-blue-600 dark:bg-blue-600/50 rounded-b-none sm:rounded-b-lg p-2 overflow-hidden hover:bg-blue-600/90 dark:hover:bg-blue-600/40" }, [
                      createVNode(unref(Link), {
                        href: _ctx.route("article.index"),
                        class: "flex justify-between items-center"
                      }, {
                        default: withCtx(() => [
                          createVNode("p", null, toDisplayString(_ctx.lang().label.more), 1),
                          createVNode(unref(ChevronRightIcon), { class: "w-5 h-5" })
                        ]),
                        _: 1
                      }, 8, ["href"])
                    ])
                  ]),
                  createVNode("div", null, [
                    createVNode("div", { class: "rounded-t-none sm:rounded-t-lg px-4 py-6 flex justify-between bg-green-600/70 dark:bg-green-600/60 items-center overflow-hidden" }, [
                      createVNode("div", null, [
                        createVNode(unref(ChatBubbleBottomCenterTextIcon), { class: "w-12 h-12" })
                      ]),
                      createVNode("div", { class: "flex justify-between items-center" }, [
                        createVNode("p", { class: "text-4xl mr-2 font-bold mb-2" }, toDisplayString(props.forums), 1),
                        createVNode("p", { class: "text-md md:text-xl uppercase text-right" }, " Forum ")
                      ])
                    ]),
                    createVNode("div", { class: "bg-green-600 dark:bg-green-600/50 rounded-b-none sm:rounded-b-lg p-2 overflow-hidden hover:bg-green-600/90 dark:hover:bg-green-600/40" }, [
                      createVNode(unref(Link), {
                        href: _ctx.route("forum.index"),
                        class: "flex justify-between items-center"
                      }, {
                        default: withCtx(() => [
                          createVNode("p", null, toDisplayString(_ctx.lang().label.more), 1),
                          createVNode(unref(ChevronRightIcon), { class: "w-5 h-5" })
                        ]),
                        _: 1
                      }, 8, ["href"])
                    ])
                  ]),
                  createVNode("div", null, [
                    createVNode("div", { class: "rounded-t-none sm:rounded-t-lg px-4 py-6 flex justify-between bg-amber-600/70 dark:bg-amber-600/60 items-center overflow-hidden" }, [
                      createVNode("div", null, [
                        createVNode(unref(PlayIcon), { class: "w-12 h-12" })
                      ]),
                      createVNode("div", { class: "flex justify-between items-center" }, [
                        createVNode("p", { class: "text-4xl mr-2 font-bold mb-2" }, toDisplayString(props.videos), 1),
                        createVNode("p", { class: "text-md md:text-xl uppercase text-right" }, " Video ")
                      ])
                    ]),
                    createVNode("div", { class: "bg-amber-600 dark:bg-amber-600/50 rounded-b-none sm:rounded-b-lg p-2 overflow-hidden hover:bg-amber-600/90 dark:hover:bg-amber-600/40" }, [
                      createVNode(unref(Link), {
                        href: _ctx.route("video.index"),
                        class: "flex justify-between items-center"
                      }, {
                        default: withCtx(() => [
                          createVNode("p", null, toDisplayString(_ctx.lang().label.more), 1),
                          createVNode(unref(ChevronRightIcon), { class: "w-5 h-5" })
                        ]),
                        _: 1
                      }, 8, ["href"])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Dashboard.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
