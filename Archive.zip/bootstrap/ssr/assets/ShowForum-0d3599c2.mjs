import { withCtx, unref, createVNode, openBlock, createBlock, Fragment, renderList, toDisplayString, withModifiers, createCommentVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrInterpolate } from "vue/server-renderer";
import { useForm, Link } from "@inertiajs/inertia-vue3";
import { _ as _sfc_main$1 } from "./HomeLayout-6d6c8674.mjs";
import { _ as _sfc_main$2 } from "./TextInput-a82a0582.mjs";
import "./Ckeditor-4f66a042.mjs";
import { UserCircleIcon, HandThumbUpIcon, ChatBubbleLeftEllipsisIcon, TrashIcon, PaperAirplaneIcon } from "@heroicons/vue/24/solid";
import "@headlessui/vue";
import "@heroicons/vue/24/outline";
import "./DropdownLink-8164274e.mjs";
import "./_plugin-vue_export-helper-cc2b3d55.mjs";
import "@ckeditor/ckeditor5-build-classic";
import "@ckeditor/ckeditor5-vue";
const ShowForum_vue_vue_type_style_index_0_setup_true_lang = "";
const _sfc_main = {
  __name: "ShowForum",
  __ssrInlineRender: true,
  props: {
    forums: Object,
    forumid: Number,
    userid: Number
  },
  setup(__props) {
    const props = __props;
    const form = useForm({
      id: props.forums.id,
      comment: "",
      like: props.forums.like,
      _method: "put"
    });
    function deleteLike(id) {
      form.delete(route("forum.delete-like", id));
    }
    const likeadd = () => {
      form.post(route("forum.create-like", props.forumid));
    };
    function deleteComment(id) {
      form.delete(route("forum.delete-comment", id));
    }
    const commentadd = () => {
      form.post(route("forum.create-comment", props.forumid));
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$1, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="bg-white pt-5"${_scopeId}><div class="mx-auto max-w-7xl sm:px-6 px-4 lg:px-8"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              href: _ctx.route("all-forum.allforum")
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="flex items-center pt-2 md:text-lg text-xs"${_scopeId2}><i class="fa-solid fa-chevron-left mr-1"${_scopeId2}></i><span class="font-bold"${_scopeId2}>Back to Forum</span></div>`);
                } else {
                  return [
                    createVNode("div", { class: "flex items-center pt-2 md:text-lg text-xs" }, [
                      createVNode("i", { class: "fa-solid fa-chevron-left mr-1" }),
                      createVNode("span", { class: "font-bold" }, "Back to Forum")
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div><div class="max-w-xs mx-auto overflow-hidden md:max-w-5xl lg:max-w-7xl"${_scopeId}><!--[-->`);
            ssrRenderList(__props.forums, (forum) => {
              _push2(`<div${_scopeId}><div class=""${_scopeId}><div class="py-4 md:py-6 md:ml-24 lg:p-8"${_scopeId}><div class="flex"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(UserCircleIcon), { class: "text-sky-900 w-10 h-10 md:w-12 md:h-12 lg:w-14 lg:h-14" }, null, _parent2, _scopeId));
              _push2(`<div class="mt-1.5"${_scopeId}><div class="ml-3 uppercase tracking-wide text-xs text-black font-medium md:text-base lg:text-lg"${_scopeId}>${ssrInterpolate(forum.user.name)}</div><p class="ml-3 font-medium text-sm opacity-50"${_scopeId}> Asked on ${ssrInterpolate(forum.created_at)} WIB </p><div class="mt-2 ml-3 text-black font-semibold mt-7 text-base md:text-xl lg:text-2xl"${_scopeId}>${forum.subject}</div><div class="mt-4 md:mt-6"${_scopeId}><div class="flex ml-3 text-black items-center text-sm md:text-xl"${_scopeId}>`);
              if (__props.userid != null) {
                _push2(`<div${_scopeId}>`);
                if (forum.likes_user == "") {
                  _push2(`<div${_scopeId}><form${_scopeId}><button type="submit"${_scopeId}>`);
                  _push2(ssrRenderComponent(unref(HandThumbUpIcon), { class: "w-4 h-4 md:w-5 md:h-5 lg:w-6 lg:h-6" }, null, _parent2, _scopeId));
                  _push2(`</button></form></div>`);
                } else {
                  _push2(`<div${_scopeId}><!--[-->`);
                  ssrRenderList(forum.likes_user, (like) => {
                    _push2(`<!--[-->`);
                    if (like.user_id == _ctx.$page.props.auth.user.id) {
                      _push2(`<div${_scopeId}><button tabindex="-1" type="button"${_scopeId}>`);
                      _push2(ssrRenderComponent(unref(HandThumbUpIcon), { class: "w-4 h-4 text-yellow-700 md:w-5 md:h-5 lg:w-6 lg:h-6" }, null, _parent2, _scopeId));
                      _push2(`</button></div>`);
                    } else if (like.user_id != _ctx.$page.props.auth.user.id) {
                      _push2(`<div${_scopeId}><form${_scopeId}><div className="mt-4"${_scopeId}><button type="submit"${_scopeId}>`);
                      _push2(ssrRenderComponent(unref(HandThumbUpIcon), { class: "w-4 h-4 md:w-5 md:h-5 lg:w-6 lg:h-6" }, null, _parent2, _scopeId));
                      _push2(`</button></div></form></div>`);
                    } else {
                      _push2(`<div${_scopeId}><div className="mt-4"${_scopeId}><button type="submit"${_scopeId}>`);
                      _push2(ssrRenderComponent(unref(HandThumbUpIcon), { class: "w-4 h-4 md:w-5 md:h-5 lg:w-6 lg:h-6" }, null, _parent2, _scopeId));
                      _push2(`</button></div></div>`);
                    }
                    _push2(`<!--]-->`);
                  });
                  _push2(`<!--]--></div>`);
                }
                _push2(`</div>`);
              } else {
                _push2(`<div${_scopeId}>`);
                _push2(ssrRenderComponent(unref(HandThumbUpIcon), { class: "w-4 h-4 md:w-5 md:h-5 lg:w-6 lg:h-6" }, null, _parent2, _scopeId));
                _push2(`</div>`);
              }
              _push2(`<span class="mx-2 mr-6 font-medium text-md"${_scopeId}>${ssrInterpolate(forum.likes.length)}</span>`);
              _push2(ssrRenderComponent(unref(ChatBubbleLeftEllipsisIcon), { class: "w-4 h-4 md:w-5 md:h-5 lg:w-6 lg:h-6" }, null, _parent2, _scopeId));
              _push2(`<span class="mx-2 font-medium text-md"${_scopeId}>${ssrInterpolate(forum.comments.length)}</span></div></div></div></div></div><div class="mt-7 flex max-w-xs overflow-hidden mx-auto md:max-w-xl lg:max-w-3xl"${_scopeId}><a class="w-full text-white py-2 h-full bg-sky-900 rounded-xl text-center" type="" href="#comment"${_scopeId}><b class="text-white"${_scopeId}>Answer Question</b></a></div></div><!--[-->`);
              ssrRenderList(forum.comments, (comment) => {
                _push2(`<div${_scopeId}><br${_scopeId}><br${_scopeId}><hr class="m-auto border-t-2"${_scopeId}><br${_scopeId}><br${_scopeId}>`);
                if (__props.userid != null) {
                  _push2(`<div${_scopeId}><div class="py-4 md:py-6 md:ml-24 lg:p-8"${_scopeId}><div class="flex"${_scopeId}>`);
                  _push2(ssrRenderComponent(unref(UserCircleIcon), { class: "text-sky-900 w-10 h-10 md:w-12 md:h-12 lg:w-14 lg:h-14" }, null, _parent2, _scopeId));
                  _push2(`<div class="mt-1.5"${_scopeId}><div class="ml-3 uppercase tracking-wide text-xs text-black font-medium md:text-base lg:text-lg"${_scopeId}>${ssrInterpolate(comment.user.name)}</div><div class="flex justify-between"${_scopeId}><p class="flex ml-3 font-medium text-sm opacity-50"${_scopeId}> Answered On ${ssrInterpolate(comment.created_at)} WIB </p>`);
                  if (comment.user_id == __props.userid) {
                    _push2(`<div${_scopeId}><button tabindex="-1" type="button" class="mx-4 my-auto"${_scopeId}>`);
                    _push2(ssrRenderComponent(unref(TrashIcon), { class: "w-4 h-4 md:w-4 md:h-4 lg:w-4 lg:h-4 text-rose-700" }, null, _parent2, _scopeId));
                    _push2(`</button></div>`);
                  } else {
                    _push2(`<!---->`);
                  }
                  _push2(`</div><div class="mt-2 ml-3 text-black font-normal mt-7 text-base md:text-xl lg:text-2xl"${_scopeId}>${comment.comment}</div></div></div></div></div>`);
                } else {
                  _push2(`<div${_scopeId}><div class="py-4 md:py-6 md:ml-24 lg:p-8"${_scopeId}><div class="flex"${_scopeId}>`);
                  _push2(ssrRenderComponent(unref(UserCircleIcon), { class: "text-sky-900 w-10 h-10 md:w-12 md:h-12 lg:w-14 lg:h-14" }, null, _parent2, _scopeId));
                  _push2(`<div class="mt-1.5"${_scopeId}><div class="ml-3 uppercase tracking-wide text-xs text-black font-medium md:text-base lg:text-lg"${_scopeId}>${ssrInterpolate(comment.user.name)}</div><div class="flex justify-between"${_scopeId}><p class="flex ml-3 font-medium text-sm opacity-50"${_scopeId}> Answered On ${ssrInterpolate(comment.created_at)} WIB </p>`);
                  if (comment.user_id == __props.userid) {
                    _push2(`<div${_scopeId}><button tabindex="-1" type="button" class="mx-4 my-auto"${_scopeId}>`);
                    _push2(ssrRenderComponent(unref(TrashIcon), { class: "w-4 h-4 md:w-4 md:h-4 lg:w-4 lg:h-4 text-rose-700" }, null, _parent2, _scopeId));
                    _push2(`</button></div>`);
                  } else {
                    _push2(`<!---->`);
                  }
                  _push2(`</div><div class="mt-2 ml-3 text-black font-normal mt-7 text-base md:text-xl lg:text-2xl"${_scopeId}>${comment.comment}</div></div></div></div></div>`);
                }
                _push2(`</div>`);
              });
              _push2(`<!--]--></div>`);
            });
            _push2(`<!--]--></div>`);
            if (__props.userid != null) {
              _push2(`<div id="comment"${_scopeId}><div class="lg:p-8 w-full"${_scopeId}><form${_scopeId}><div class="flex max-w-xs overflow-hidden mx-auto w-full md:max-w-xl lg:max-w-3xl"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(UserCircleIcon), { class: "text-sky-900 w-12 h-12 my-auto mr-2 md:w-14 md:h-14 lg:w-16 lg:h-16" }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_sfc_main$2, {
                id: "title",
                type: "text",
                placeholder: "Comment ..",
                class: "mt-4 mb-4 bg-sky-900 text-white block w-full placeholder:text-slate-100 placeholder:italic focus:border-sky-900 focus:ring-sky-900",
                modelValue: unref(form).comment,
                "onUpdate:modelValue": ($event) => unref(form).comment = $event
              }, null, _parent2, _scopeId));
              _push2(`<button type="submit"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(PaperAirplaneIcon), { class: "text-sky-900 w-8 h-8 my-auto ml-2" }, null, _parent2, _scopeId));
              _push2(`</button></div></form></div></div>`);
            } else {
              _push2(`<div id="comment"${_scopeId}><div class="lg:p-8 w-full"${_scopeId}><div class="flex max-w-xs overflow-hidden mx-auto w-full md:max-w-xl lg:max-w-3xl"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(UserCircleIcon), { class: "text-sky-900 w-12 h-12 mr-2 my-auto md:w-14 md:h-14 lg:w-16 lg:h-16" }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_sfc_main$2, {
                id: "title",
                type: "text",
                placeholder: "Login to write answer ..",
                class: "mt-4 mb-4 bg-sky-900 text-white block w-full placeholder:text-slate-100 placeholder:italic focus:border-sky-900 focus:ring-sky-900",
                modelValue: unref(form).comment,
                "onUpdate:modelValue": ($event) => unref(form).comment = $event,
                disabled: ""
              }, null, _parent2, _scopeId));
              _push2(`<button${_scopeId}>`);
              _push2(ssrRenderComponent(unref(PaperAirplaneIcon), { class: "text-sky-900 w-8 h-8 my-auto ml-2" }, null, _parent2, _scopeId));
              _push2(`</button></div></div></div>`);
            }
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "bg-white pt-5" }, [
                createVNode("div", { class: "mx-auto max-w-7xl sm:px-6 px-4 lg:px-8" }, [
                  createVNode(unref(Link), {
                    href: _ctx.route("all-forum.allforum")
                  }, {
                    default: withCtx(() => [
                      createVNode("div", { class: "flex items-center pt-2 md:text-lg text-xs" }, [
                        createVNode("i", { class: "fa-solid fa-chevron-left mr-1" }),
                        createVNode("span", { class: "font-bold" }, "Back to Forum")
                      ])
                    ]),
                    _: 1
                  }, 8, ["href"])
                ]),
                createVNode("div", { class: "max-w-xs mx-auto overflow-hidden md:max-w-5xl lg:max-w-7xl" }, [
                  (openBlock(true), createBlock(Fragment, null, renderList(__props.forums, (forum) => {
                    return openBlock(), createBlock("div", {
                      key: forum.id
                    }, [
                      createVNode("div", { class: "" }, [
                        createVNode("div", { class: "py-4 md:py-6 md:ml-24 lg:p-8" }, [
                          createVNode("div", { class: "flex" }, [
                            createVNode(unref(UserCircleIcon), { class: "text-sky-900 w-10 h-10 md:w-12 md:h-12 lg:w-14 lg:h-14" }),
                            createVNode("div", { class: "mt-1.5" }, [
                              createVNode("div", { class: "ml-3 uppercase tracking-wide text-xs text-black font-medium md:text-base lg:text-lg" }, toDisplayString(forum.user.name), 1),
                              createVNode("p", { class: "ml-3 font-medium text-sm opacity-50" }, " Asked on " + toDisplayString(forum.created_at) + " WIB ", 1),
                              createVNode("div", {
                                class: "mt-2 ml-3 text-black font-semibold mt-7 text-base md:text-xl lg:text-2xl",
                                innerHTML: forum.subject
                              }, null, 8, ["innerHTML"]),
                              createVNode("div", { class: "mt-4 md:mt-6" }, [
                                createVNode("div", { class: "flex ml-3 text-black items-center text-sm md:text-xl" }, [
                                  __props.userid != null ? (openBlock(), createBlock("div", { key: 0 }, [
                                    forum.likes_user == "" ? (openBlock(), createBlock("div", { key: 0 }, [
                                      createVNode("form", {
                                        onSubmit: withModifiers(likeadd, ["prevent"])
                                      }, [
                                        createVNode("button", { type: "submit" }, [
                                          createVNode(unref(HandThumbUpIcon), { class: "w-4 h-4 md:w-5 md:h-5 lg:w-6 lg:h-6" })
                                        ])
                                      ], 40, ["onSubmit"])
                                    ])) : (openBlock(), createBlock("div", { key: 1 }, [
                                      (openBlock(true), createBlock(Fragment, null, renderList(forum.likes_user, (like) => {
                                        return openBlock(), createBlock(Fragment, { key: like }, [
                                          like.user_id == _ctx.$page.props.auth.user.id ? (openBlock(), createBlock("div", { key: 0 }, [
                                            createVNode("button", {
                                              onClick: ($event) => deleteLike(like.id),
                                              tabindex: "-1",
                                              type: "button"
                                            }, [
                                              createVNode(unref(HandThumbUpIcon), { class: "w-4 h-4 text-yellow-700 md:w-5 md:h-5 lg:w-6 lg:h-6" })
                                            ], 8, ["onClick"])
                                          ])) : like.user_id != _ctx.$page.props.auth.user.id ? (openBlock(), createBlock("div", { key: 1 }, [
                                            createVNode("form", {
                                              onSubmit: withModifiers(likeadd, ["prevent"])
                                            }, [
                                              createVNode("div", { className: "mt-4" }, [
                                                createVNode("button", { type: "submit" }, [
                                                  createVNode(unref(HandThumbUpIcon), { class: "w-4 h-4 md:w-5 md:h-5 lg:w-6 lg:h-6" })
                                                ])
                                              ])
                                            ], 40, ["onSubmit"])
                                          ])) : (openBlock(), createBlock("div", { key: 2 }, [
                                            createVNode("div", { className: "mt-4" }, [
                                              createVNode("button", { type: "submit" }, [
                                                createVNode(unref(HandThumbUpIcon), { class: "w-4 h-4 md:w-5 md:h-5 lg:w-6 lg:h-6" })
                                              ])
                                            ])
                                          ]))
                                        ], 64);
                                      }), 128))
                                    ]))
                                  ])) : (openBlock(), createBlock("div", { key: 1 }, [
                                    createVNode(unref(HandThumbUpIcon), { class: "w-4 h-4 md:w-5 md:h-5 lg:w-6 lg:h-6" })
                                  ])),
                                  createVNode("span", { class: "mx-2 mr-6 font-medium text-md" }, toDisplayString(forum.likes.length), 1),
                                  createVNode(unref(ChatBubbleLeftEllipsisIcon), { class: "w-4 h-4 md:w-5 md:h-5 lg:w-6 lg:h-6" }),
                                  createVNode("span", { class: "mx-2 font-medium text-md" }, toDisplayString(forum.comments.length), 1)
                                ])
                              ])
                            ])
                          ])
                        ]),
                        createVNode("div", { class: "mt-7 flex max-w-xs overflow-hidden mx-auto md:max-w-xl lg:max-w-3xl" }, [
                          createVNode("a", {
                            class: "w-full text-white py-2 h-full bg-sky-900 rounded-xl text-center",
                            type: "",
                            href: "#comment"
                          }, [
                            createVNode("b", { class: "text-white" }, "Answer Question")
                          ])
                        ])
                      ]),
                      (openBlock(true), createBlock(Fragment, null, renderList(forum.comments, (comment) => {
                        return openBlock(), createBlock("div", {
                          key: comment.id
                        }, [
                          createVNode("br"),
                          createVNode("br"),
                          createVNode("hr", { class: "m-auto border-t-2" }),
                          createVNode("br"),
                          createVNode("br"),
                          __props.userid != null ? (openBlock(), createBlock("div", { key: 0 }, [
                            createVNode("div", { class: "py-4 md:py-6 md:ml-24 lg:p-8" }, [
                              createVNode("div", { class: "flex" }, [
                                createVNode(unref(UserCircleIcon), { class: "text-sky-900 w-10 h-10 md:w-12 md:h-12 lg:w-14 lg:h-14" }),
                                createVNode("div", { class: "mt-1.5" }, [
                                  createVNode("div", { class: "ml-3 uppercase tracking-wide text-xs text-black font-medium md:text-base lg:text-lg" }, toDisplayString(comment.user.name), 1),
                                  createVNode("div", { class: "flex justify-between" }, [
                                    createVNode("p", { class: "flex ml-3 font-medium text-sm opacity-50" }, " Answered On " + toDisplayString(comment.created_at) + " WIB ", 1),
                                    comment.user_id == __props.userid ? (openBlock(), createBlock("div", { key: 0 }, [
                                      createVNode("button", {
                                        onClick: ($event) => deleteComment(comment.id),
                                        tabindex: "-1",
                                        type: "button",
                                        class: "mx-4 my-auto"
                                      }, [
                                        createVNode(unref(TrashIcon), { class: "w-4 h-4 md:w-4 md:h-4 lg:w-4 lg:h-4 text-rose-700" })
                                      ], 8, ["onClick"])
                                    ])) : createCommentVNode("", true)
                                  ]),
                                  createVNode("div", {
                                    class: "mt-2 ml-3 text-black font-normal mt-7 text-base md:text-xl lg:text-2xl",
                                    innerHTML: comment.comment
                                  }, null, 8, ["innerHTML"])
                                ])
                              ])
                            ])
                          ])) : (openBlock(), createBlock("div", { key: 1 }, [
                            createVNode("div", { class: "py-4 md:py-6 md:ml-24 lg:p-8" }, [
                              createVNode("div", { class: "flex" }, [
                                createVNode(unref(UserCircleIcon), { class: "text-sky-900 w-10 h-10 md:w-12 md:h-12 lg:w-14 lg:h-14" }),
                                createVNode("div", { class: "mt-1.5" }, [
                                  createVNode("div", { class: "ml-3 uppercase tracking-wide text-xs text-black font-medium md:text-base lg:text-lg" }, toDisplayString(comment.user.name), 1),
                                  createVNode("div", { class: "flex justify-between" }, [
                                    createVNode("p", { class: "flex ml-3 font-medium text-sm opacity-50" }, " Answered On " + toDisplayString(comment.created_at) + " WIB ", 1),
                                    comment.user_id == __props.userid ? (openBlock(), createBlock("div", { key: 0 }, [
                                      createVNode("button", {
                                        onClick: ($event) => deleteComment(comment.id),
                                        tabindex: "-1",
                                        type: "button",
                                        class: "mx-4 my-auto"
                                      }, [
                                        createVNode(unref(TrashIcon), { class: "w-4 h-4 md:w-4 md:h-4 lg:w-4 lg:h-4 text-rose-700" })
                                      ], 8, ["onClick"])
                                    ])) : createCommentVNode("", true)
                                  ]),
                                  createVNode("div", {
                                    class: "mt-2 ml-3 text-black font-normal mt-7 text-base md:text-xl lg:text-2xl",
                                    innerHTML: comment.comment
                                  }, null, 8, ["innerHTML"])
                                ])
                              ])
                            ])
                          ]))
                        ]);
                      }), 128))
                    ]);
                  }), 128))
                ]),
                __props.userid != null ? (openBlock(), createBlock("div", {
                  key: 0,
                  id: "comment"
                }, [
                  createVNode("div", { class: "lg:p-8 w-full" }, [
                    createVNode("form", {
                      onSubmit: withModifiers(commentadd, ["prevent"])
                    }, [
                      createVNode("div", { class: "flex max-w-xs overflow-hidden mx-auto w-full md:max-w-xl lg:max-w-3xl" }, [
                        createVNode(unref(UserCircleIcon), { class: "text-sky-900 w-12 h-12 my-auto mr-2 md:w-14 md:h-14 lg:w-16 lg:h-16" }),
                        createVNode(_sfc_main$2, {
                          id: "title",
                          type: "text",
                          placeholder: "Comment ..",
                          class: "mt-4 mb-4 bg-sky-900 text-white block w-full placeholder:text-slate-100 placeholder:italic focus:border-sky-900 focus:ring-sky-900",
                          modelValue: unref(form).comment,
                          "onUpdate:modelValue": ($event) => unref(form).comment = $event
                        }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                        createVNode("button", { type: "submit" }, [
                          createVNode(unref(PaperAirplaneIcon), { class: "text-sky-900 w-8 h-8 my-auto ml-2" })
                        ])
                      ])
                    ], 40, ["onSubmit"])
                  ])
                ])) : (openBlock(), createBlock("div", {
                  key: 1,
                  id: "comment"
                }, [
                  createVNode("div", { class: "lg:p-8 w-full" }, [
                    createVNode("div", { class: "flex max-w-xs overflow-hidden mx-auto w-full md:max-w-xl lg:max-w-3xl" }, [
                      createVNode(unref(UserCircleIcon), { class: "text-sky-900 w-12 h-12 mr-2 my-auto md:w-14 md:h-14 lg:w-16 lg:h-16" }),
                      createVNode(_sfc_main$2, {
                        id: "title",
                        type: "text",
                        placeholder: "Login to write answer ..",
                        class: "mt-4 mb-4 bg-sky-900 text-white block w-full placeholder:text-slate-100 placeholder:italic focus:border-sky-900 focus:ring-sky-900",
                        modelValue: unref(form).comment,
                        "onUpdate:modelValue": ($event) => unref(form).comment = $event,
                        disabled: ""
                      }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                      createVNode("button", null, [
                        createVNode(unref(PaperAirplaneIcon), { class: "text-sky-900 w-8 h-8 my-auto ml-2" })
                      ])
                    ])
                  ])
                ]))
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/FrontEnd/ShowForum.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
