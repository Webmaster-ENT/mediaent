import { withCtx, createVNode, openBlock, createBlock, Fragment, renderList, toDisplayString, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrRenderAttr, ssrInterpolate } from "vue/server-renderer";
import "@inertiajs/inertia-vue3";
import { _ as _sfc_main$1 } from "./HomeLayout-6d6c8674.mjs";
import "@heroicons/vue/24/solid";
import "@headlessui/vue";
import "@heroicons/vue/24/outline";
import "./DropdownLink-8164274e.mjs";
import "./_plugin-vue_export-helper-cc2b3d55.mjs";
const _sfc_main = {
  __name: "Video",
  __ssrInlineRender: true,
  props: {
    videos: Object
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(_sfc_main$1, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="bg-sky-900"${_scopeId}><div class="max-w-xs mx-auto overflow-hidden md:max-w-5xl lg:max-w-7xl"${_scopeId}><br${_scopeId}><br${_scopeId}><br${_scopeId}><div class="container mx-auto px-6 sm:flex sm:flex-wrap sm:gap-6 sm:justify-center"${_scopeId}><!--[-->`);
            ssrRenderList(__props.videos, (video) => {
              _push2(`<div${_scopeId}><div class="p-4 rounded-2xl shadow-lg overflow-hidden mb-10 bg-white sm:mb-0 sm:w-64 md:w-80 lg:w-72 xl:w-96"${_scopeId}><iframe${ssrRenderAttr("src", video.video_url)} class="rounded-2xl w-full aspect-video" frameborder="0" title="YouTube video player" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen${_scopeId}></iframe><div class="mt-3 text-sm font-bold text-center h-14"${_scopeId}><p${_scopeId}>${ssrInterpolate(video.title)}</p></div><div class="mt-3 float-right inline-block text-xs px-6 py-2 rounded-3xl font-semibold bg-sky-900 text-white w-auto"${_scopeId}><a href=""${_scopeId}>Play</a></div></div><br${_scopeId}></div>`);
            });
            _push2(`<!--]--></div></div><br${_scopeId}><br${_scopeId}><br${_scopeId}><br${_scopeId}><br${_scopeId}></div>`);
          } else {
            return [
              createVNode("div", { class: "bg-sky-900" }, [
                createVNode("div", { class: "max-w-xs mx-auto overflow-hidden md:max-w-5xl lg:max-w-7xl" }, [
                  createVNode("br"),
                  createVNode("br"),
                  createVNode("br"),
                  createVNode("div", { class: "container mx-auto px-6 sm:flex sm:flex-wrap sm:gap-6 sm:justify-center" }, [
                    (openBlock(true), createBlock(Fragment, null, renderList(__props.videos, (video) => {
                      return openBlock(), createBlock("div", {
                        key: video.id
                      }, [
                        createVNode("div", { class: "p-4 rounded-2xl shadow-lg overflow-hidden mb-10 bg-white sm:mb-0 sm:w-64 md:w-80 lg:w-72 xl:w-96" }, [
                          createVNode("iframe", {
                            src: video.video_url,
                            class: "rounded-2xl w-full aspect-video",
                            frameborder: "0",
                            title: "YouTube video player",
                            allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share",
                            allowfullscreen: ""
                          }, null, 8, ["src"]),
                          createVNode("div", { class: "mt-3 text-sm font-bold text-center h-14" }, [
                            createVNode("p", null, toDisplayString(video.title), 1)
                          ]),
                          createVNode("div", { class: "mt-3 float-right inline-block text-xs px-6 py-2 rounded-3xl font-semibold bg-sky-900 text-white w-auto" }, [
                            createVNode("a", { href: "" }, "Play")
                          ])
                        ]),
                        createVNode("br")
                      ]);
                    }), 128))
                  ])
                ]),
                createVNode("br"),
                createVNode("br"),
                createVNode("br"),
                createVNode("br"),
                createVNode("br")
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/FrontEnd/Video.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
