import { ref, watch, mergeProps, unref, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent } from "vue/server-renderer";
import ClassicEditor from "@ckeditor/ckeditor5-build-classic";
import { component } from "@ckeditor/ckeditor5-vue";
const Ckeditor_vue_vue_type_style_index_0_lang = "";
const _sfc_main = {
  __name: "Ckeditor",
  __ssrInlineRender: true,
  props: {
    modelValue: String
  },
  emits: ["update:modelValue"],
  setup(__props, { emit }) {
    const props = __props;
    const editorData = ref(props.modelValue || "");
    ref({
      toolbar: [
        "heading",
        "|",
        "bold",
        "italic",
        "link",
        "bulletedList",
        "numberedList",
        "blockQuote"
      ],
      fontSize: {
        options: [9, 11, 13, "default", 17, 19, 21, 27, 35],
        supportAllValues: false
      },
      plugins: ["Essentials", "Paragraph", "Heading", "List", "Bold", "Italic"],
      heading: {
        options: [
          {
            model: "paragraph",
            title: "Paragraph",
            class: "ck-heading_paragraph"
          },
          {
            model: "heading1",
            view: "h1",
            title: "Heading 1",
            class: "ck-heading_heading1"
          },
          {
            model: "heading2",
            view: "h2",
            title: "Heading 2",
            class: "ck-heading_heading2"
          }
        ]
      }
    });
    watch(editorData, () => {
      emit("update:modelValue", editorData.value);
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: "fg-block",
        style: { "--ck-border-radius": "0.5rem" }
      }, _attrs))}>`);
      _push(ssrRenderComponent(unref(component), {
        editor: unref(ClassicEditor),
        modelValue: editorData.value,
        "onUpdate:modelValue": ($event) => editorData.value = $event
      }, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Ckeditor.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as _
};
