import { mergeProps, unref, withCtx, createVNode, createTextVNode, toDisplayString, withDirectives, vShow, useSSRContext, resolveComponent, reactive, ref } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderClass, ssrRenderSlot, ssrRenderList } from "vue/server-renderer";
import "./ApplicationLogo-0976b5e5.mjs";
import { _ as _sfc_main$8, a as _sfc_main$9 } from "./DropdownLink-8164274e.mjs";
import { Link } from "@inertiajs/inertia-vue3";
import { Bars3CenterLeftIcon, UserIcon, CheckCircleIcon, ChevronDownIcon, CheckBadgeIcon, HomeIcon, ClipboardDocumentListIcon, ChatBubbleBottomCenterTextIcon, PlayIcon, XMarkIcon, ExclamationCircleIcon, InformationCircleIcon, ExclamationTriangleIcon, ArrowSmallUpIcon, ChevronRightIcon } from "@heroicons/vue/24/solid";
import { TransitionRoot, Dialog, TransitionChild, DialogOverlay } from "@headlessui/vue";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.mjs";
const _sfc_main$7 = {
  __name: "NavBar",
  __ssrInlineRender: true,
  emits: ["open"],
  setup(__props, { emit }) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<nav${ssrRenderAttrs(mergeProps({ class: "bg-gray-900 border-gray-700 text-gray-300 lg:bg-white dark:bg-gray-900 border-b lg:border-gray-100 dark:border-gray-800 lg:text-gray-500 dark:text-gray-300" }, _attrs))}><div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"><div class="flex justify-between h-16"><div class="flex"><div class="mr-4 shrink-0 flex items-center lg:hidden"><button class="hover:text-gray-400 hover:bg-gray-900 focus:bg-gray-900 focus:text-gray-400 inline-flex items-center justify-center p-2 rounded-md lg:hover:text-gray-500 dark:hover:text-gray-400 lg:hover:bg-gray-100 dark:hover:bg-gray-900 focus:outline-none lg:focus:bg-gray-100 dark:focus:bg-gray-900 lg:focus:text-gray-500 dark:focus:text-gray-400 transition duration-150 ease-in-out">`);
      _push(ssrRenderComponent(unref(Bars3CenterLeftIcon), { class: "h-6 w-6" }, null, _parent));
      _push(`</button></div><div class="flex">`);
      _push(ssrRenderComponent(unref(Link), {
        href: _ctx.route("dashboard"),
        class: "flex items-center space-x-2"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img src="Logo-ENT-Gelap.svg" class="w-12" alt=""${_scopeId}><p${_scopeId}>Media ENT</p>`);
          } else {
            return [
              createVNode("img", {
                src: "Logo-ENT-Gelap.svg",
                class: "w-12",
                alt: ""
              }),
              createVNode("p", null, "Media ENT")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div><div class="flex items-center space-x-2"><div class=""><div class="relative">`);
      _push(ssrRenderComponent(_sfc_main$8, {
        align: "right",
        width: "48"
      }, {
        trigger: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<span class="inline-flex rounded-md"${_scopeId}><button type="button" class="hover:text-gray-400 hover:bg-gray-900 focus:bg-gray-900 focus:text-gray-400 inline-flex items-center justify-center p-2 rounded-md lg:hover:text-gray-500 dark:hover:text-gray-400 lg:hover:bg-gray-100 dark:hover:bg-gray-900 focus:outline-none lg:focus:bg-gray-100 dark:focus:bg-gray-900 lg:focus:text-gray-500 dark:focus:text-gray-400 transition duration-150 ease-in-out sm:hidden"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(UserIcon), { class: "h-4 w-4" }, null, _parent2, _scopeId));
            _push2(`</button><button type="button" class="hover:text-gray-400 hover:bg-gray-900 focus:bg-gray-900 focus:text-gray-400 items-center justify-center p-2 rounded-md lg:hover:text-gray-500 dark:hover:text-gray-400 lg:hover:bg-gray-100 dark:hover:bg-gray-900 focus:outline-none lg:focus:bg-gray-100 dark:focus:bg-gray-900 lg:focus:text-gray-500 dark:focus:text-gray-400 transition duration-150 ease-in-out truncate w-fit hidden sm:inline-flex"${_scopeId}><span class="flex justify-between items-center"${_scopeId}>${ssrInterpolate(_ctx.$page.props.auth.user.name.split(
              " "
            )[0])} `);
            _push2(ssrRenderComponent(unref(CheckCircleIcon), {
              class: "ml-[2px] w-4 h-4 text-white dark:text-white lg:text-blue-600",
              style: _ctx.$page.props.auth.user.email_verified_at ? null : { display: "none" }
            }, null, _parent2, _scopeId));
            _push2(`</span>`);
            _push2(ssrRenderComponent(unref(ChevronDownIcon), { class: "ml-2 h-4 w-4 fill-current" }, null, _parent2, _scopeId));
            _push2(`</button></span>`);
          } else {
            return [
              createVNode("span", { class: "inline-flex rounded-md" }, [
                createVNode("button", {
                  type: "button",
                  class: "hover:text-gray-400 hover:bg-gray-900 focus:bg-gray-900 focus:text-gray-400 inline-flex items-center justify-center p-2 rounded-md lg:hover:text-gray-500 dark:hover:text-gray-400 lg:hover:bg-gray-100 dark:hover:bg-gray-900 focus:outline-none lg:focus:bg-gray-100 dark:focus:bg-gray-900 lg:focus:text-gray-500 dark:focus:text-gray-400 transition duration-150 ease-in-out sm:hidden"
                }, [
                  createVNode(unref(UserIcon), { class: "h-4 w-4" })
                ]),
                createVNode("button", {
                  type: "button",
                  class: "hover:text-gray-400 hover:bg-gray-900 focus:bg-gray-900 focus:text-gray-400 items-center justify-center p-2 rounded-md lg:hover:text-gray-500 dark:hover:text-gray-400 lg:hover:bg-gray-100 dark:hover:bg-gray-900 focus:outline-none lg:focus:bg-gray-100 dark:focus:bg-gray-900 lg:focus:text-gray-500 dark:focus:text-gray-400 transition duration-150 ease-in-out truncate w-fit hidden sm:inline-flex"
                }, [
                  createVNode("span", { class: "flex justify-between items-center" }, [
                    createTextVNode(toDisplayString(_ctx.$page.props.auth.user.name.split(
                      " "
                    )[0]) + " ", 1),
                    withDirectives(createVNode(unref(CheckCircleIcon), { class: "ml-[2px] w-4 h-4 text-white dark:text-white lg:text-blue-600" }, null, 512), [
                      [
                        vShow,
                        _ctx.$page.props.auth.user.email_verified_at
                      ]
                    ])
                  ]),
                  createVNode(unref(ChevronDownIcon), { class: "ml-2 h-4 w-4 fill-current" })
                ])
              ])
            ];
          }
        }),
        content: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="py-3 px-4 border-b border-gray-200 dark:border-gray-600 text-gray-700 dark:text-gray-300"${_scopeId}><span class="flex items-center justify-start text-sm truncate"${_scopeId}>${ssrInterpolate(_ctx.$page.props.auth.user.name)} `);
            _push2(ssrRenderComponent(unref(CheckCircleIcon), {
              class: "ml-[2px] w-4 h-4 dark:text-white text-blue-600",
              style: _ctx.$page.props.auth.user.email_verified_at ? null : { display: "none" }
            }, null, _parent2, _scopeId));
            _push2(`</span><span class="block text-sm font-medium text-gray-500 truncate dark:text-gray-400"${_scopeId}>${ssrInterpolate(_ctx.$page.props.auth.user.email)}</span></div>`);
            _push2(ssrRenderComponent(_sfc_main$9, {
              href: _ctx.route("profile.edit")
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.lang().label.profile)}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.lang().label.profile), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$9, {
              href: _ctx.route("logout"),
              method: "post",
              as: "button"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.lang().label.logout)}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.lang().label.logout), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode("div", { class: "py-3 px-4 border-b border-gray-200 dark:border-gray-600 text-gray-700 dark:text-gray-300" }, [
                createVNode("span", { class: "flex items-center justify-start text-sm truncate" }, [
                  createTextVNode(toDisplayString(_ctx.$page.props.auth.user.name) + " ", 1),
                  withDirectives(createVNode(unref(CheckCircleIcon), { class: "ml-[2px] w-4 h-4 dark:text-white text-blue-600" }, null, 512), [
                    [
                      vShow,
                      _ctx.$page.props.auth.user.email_verified_at
                    ]
                  ])
                ]),
                createVNode("span", { class: "block text-sm font-medium text-gray-500 truncate dark:text-gray-400" }, toDisplayString(_ctx.$page.props.auth.user.email), 1)
              ]),
              createVNode(_sfc_main$9, {
                href: _ctx.route("profile.edit")
              }, {
                default: withCtx(() => [
                  createTextVNode(toDisplayString(_ctx.lang().label.profile), 1)
                ]),
                _: 1
              }, 8, ["href"]),
              createVNode(_sfc_main$9, {
                href: _ctx.route("logout"),
                method: "post",
                as: "button"
              }, {
                default: withCtx(() => [
                  createTextVNode(toDisplayString(_ctx.lang().label.logout), 1)
                ]),
                _: 1
              }, 8, ["href"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div></div></div></nav>`);
    };
  }
};
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/NavBar.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const _sfc_main$6 = {
  __name: "SideBarMenu",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "text-gray-300 pt-5 pb-20" }, _attrs))}><div class="flex justify-center"><div class="rounded-full flex items-center justify-center bg-primary text-gray-300 w-24 h-24 text-4xl uppercase">${ssrInterpolate(_ctx.$page.props.auth.user.name.match(/(^\S\S?|\b\S)?/g).join("").match(/(^\S|\S$)?/g).join(""))}</div></div><div class="text-center py-3 px-4 border-b border-gray-700"><span class="flex items-center justify-center"><p class="truncate text-md">${ssrInterpolate(_ctx.$page.props.auth.user.name)}</p><div>`);
      _push(ssrRenderComponent(unref(CheckBadgeIcon), {
        class: "ml-[2px] w-4 h-4",
        style: _ctx.$page.props.auth.user.email_verified_at ? null : { display: "none" }
      }, null, _parent));
      _push(`</div></span><span class="block text-sm font-medium truncate">${ssrInterpolate(_ctx.$page.props.auth.user.roles[0].name)}</span></div><ul class="space-y-2 my-4"><li class="${ssrRenderClass([{ "bg-gray-700": !_ctx.route().current("dashboard") }, "bg-primary text-white rounded-lg hover:bg-primary"])}">`);
      _push(ssrRenderComponent(unref(Link), {
        href: _ctx.route("dashboard"),
        class: "flex items-center py-2 px-4"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(HomeIcon), { class: "w-6 h-5" }, null, _parent2, _scopeId));
            _push2(`<span class="ml-3"${_scopeId}>Dashboard</span>`);
          } else {
            return [
              createVNode(unref(HomeIcon), { class: "w-6 h-5" }),
              createVNode("span", { class: "ml-3" }, "Dashboard")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li class="py-2"><p>Site</p></li><li class="${ssrRenderClass([{ "bg-gray-700": !_ctx.route().current("article.index") }, "bg-primary text-white rounded-lg hover:bg-primary"])}">`);
      _push(ssrRenderComponent(unref(Link), {
        href: _ctx.route("article.index"),
        class: "flex items-center py-2 px-4"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(ClipboardDocumentListIcon), { class: "w-6 h-5" }, null, _parent2, _scopeId));
            _push2(`<span class="ml-3"${_scopeId}>Article</span>`);
          } else {
            return [
              createVNode(unref(ClipboardDocumentListIcon), { class: "w-6 h-5" }),
              createVNode("span", { class: "ml-3" }, "Article")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li class="${ssrRenderClass([{ "bg-gray-700": !_ctx.route().current("forum.index") }, "bg-primary text-white rounded-lg hover:bg-primary"])}">`);
      _push(ssrRenderComponent(unref(Link), {
        href: _ctx.route("forum.index"),
        class: "flex items-center py-2 px-4"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(ChatBubbleBottomCenterTextIcon), { class: "w-6 h-5" }, null, _parent2, _scopeId));
            _push2(`<span class="ml-3"${_scopeId}>Forum</span>`);
          } else {
            return [
              createVNode(unref(ChatBubbleBottomCenterTextIcon), { class: "w-6 h-5" }),
              createVNode("span", { class: "ml-3" }, "Forum")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li class="${ssrRenderClass([{ "bg-gray-700": !_ctx.route().current("video.index") }, "bg-primary text-white rounded-lg hover:bg-primary"])}">`);
      _push(ssrRenderComponent(unref(Link), {
        href: _ctx.route("video.index"),
        class: "flex items-center py-2 px-4"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(PlayIcon), { class: "w-6 h-5" }, null, _parent2, _scopeId));
            _push2(`<span class="ml-3"${_scopeId}>Video</span>`);
          } else {
            return [
              createVNode(unref(PlayIcon), { class: "w-6 h-5" }),
              createVNode("span", { class: "ml-3" }, "Video")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li></ul></div>`);
    };
  }
};
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/SideBarMenu.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const _sfc_main$5 = {
  __name: "SideBar",
  __ssrInlineRender: true,
  props: {
    open: Boolean
  },
  emits: ["close"],
  setup(__props, { emit }) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><div class="hidden lg:flex"><aside class="fixed lg:flex flex-col h-screen overflow-hidden w-64 bg-gray-800 dark:border-r dark:border-gray-700"><div class="flex-1 h-screen overflow-y-auto scrollbar-sidebar px-3">`);
      _push(ssrRenderComponent(_sfc_main$6, null, null, _parent));
      _push(`</div></aside></div>`);
      _push(ssrRenderComponent(unref(TransitionRoot), { show: __props.open }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Dialog), {
              as: "div",
              onClose: ($event) => emit("close"),
              class: "fixed inset-0 z-10 flex lg:hidden"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(TransitionChild), {
                    enter: "transition ease-in-out duration-200 transform",
                    "enter-from": "-translate-x-full",
                    "enter-to": "translate-x-0",
                    leave: "transition ease-in-out duration-200 transform",
                    "leave-from": "translate-x-0",
                    "leave-to": "-translate-x-full",
                    as: "template"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<aside class="flex flex-col relative z-10 w-64 bg-gray-800 dark:border-r dark:border-gray-700"${_scopeId3}><div class="flex flex-col relative h-screen min-h-screen"${_scopeId3}><div class="overflow-y-auto flex-1 scrollbar-sidebar px-3"${_scopeId3}>`);
                        _push4(ssrRenderComponent(_sfc_main$6, null, null, _parent4, _scopeId3));
                        _push4(`</div></div></aside>`);
                      } else {
                        return [
                          createVNode("aside", { class: "flex flex-col relative z-10 w-64 bg-gray-800 dark:border-r dark:border-gray-700" }, [
                            createVNode("div", { class: "flex flex-col relative h-screen min-h-screen" }, [
                              createVNode("div", { class: "overflow-y-auto flex-1 scrollbar-sidebar px-3" }, [
                                createVNode(_sfc_main$6)
                              ])
                            ])
                          ])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(unref(TransitionChild), {
                    enter: "transition-opacity ease-linear duration-200",
                    "enter-from": "opacity-0",
                    "enter-to": "opacity-100",
                    leave: "transition-opacity ease-linear duration-200",
                    "leave-from": "opacity-100",
                    "leave-to": "opacity-0",
                    as: "template"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(unref(DialogOverlay), { class: "fixed inset-0 bg-gray-500 dark:bg-gray-900 opacity-75 lg:hidden" }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(unref(DialogOverlay), { class: "fixed inset-0 bg-gray-500 dark:bg-gray-900 opacity-75 lg:hidden" })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(unref(TransitionChild), {
                      enter: "transition ease-in-out duration-200 transform",
                      "enter-from": "-translate-x-full",
                      "enter-to": "translate-x-0",
                      leave: "transition ease-in-out duration-200 transform",
                      "leave-from": "translate-x-0",
                      "leave-to": "-translate-x-full",
                      as: "template"
                    }, {
                      default: withCtx(() => [
                        createVNode("aside", { class: "flex flex-col relative z-10 w-64 bg-gray-800 dark:border-r dark:border-gray-700" }, [
                          createVNode("div", { class: "flex flex-col relative h-screen min-h-screen" }, [
                            createVNode("div", { class: "overflow-y-auto flex-1 scrollbar-sidebar px-3" }, [
                              createVNode(_sfc_main$6)
                            ])
                          ])
                        ])
                      ]),
                      _: 1
                    }),
                    createVNode(unref(TransitionChild), {
                      enter: "transition-opacity ease-linear duration-200",
                      "enter-from": "opacity-0",
                      "enter-to": "opacity-100",
                      leave: "transition-opacity ease-linear duration-200",
                      "leave-from": "opacity-100",
                      "leave-to": "opacity-0",
                      as: "template"
                    }, {
                      default: withCtx(() => [
                        createVNode(unref(DialogOverlay), { class: "fixed inset-0 bg-gray-500 dark:bg-gray-900 opacity-75 lg:hidden" })
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(Dialog), {
                as: "div",
                onClose: ($event) => emit("close"),
                class: "fixed inset-0 z-10 flex lg:hidden"
              }, {
                default: withCtx(() => [
                  createVNode(unref(TransitionChild), {
                    enter: "transition ease-in-out duration-200 transform",
                    "enter-from": "-translate-x-full",
                    "enter-to": "translate-x-0",
                    leave: "transition ease-in-out duration-200 transform",
                    "leave-from": "translate-x-0",
                    "leave-to": "-translate-x-full",
                    as: "template"
                  }, {
                    default: withCtx(() => [
                      createVNode("aside", { class: "flex flex-col relative z-10 w-64 bg-gray-800 dark:border-r dark:border-gray-700" }, [
                        createVNode("div", { class: "flex flex-col relative h-screen min-h-screen" }, [
                          createVNode("div", { class: "overflow-y-auto flex-1 scrollbar-sidebar px-3" }, [
                            createVNode(_sfc_main$6)
                          ])
                        ])
                      ])
                    ]),
                    _: 1
                  }),
                  createVNode(unref(TransitionChild), {
                    enter: "transition-opacity ease-linear duration-200",
                    "enter-from": "opacity-0",
                    "enter-to": "opacity-100",
                    leave: "transition-opacity ease-linear duration-200",
                    "leave-from": "opacity-100",
                    "leave-to": "opacity-0",
                    as: "template"
                  }, {
                    default: withCtx(() => [
                      createVNode(unref(DialogOverlay), { class: "fixed inset-0 bg-gray-500 dark:bg-gray-900 opacity-75 lg:hidden" })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }, 8, ["onClose"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/SideBar.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const Toast_vue_vue_type_style_index_0_lang = "";
const _sfc_main$4 = {
  components: {
    XMarkIcon,
    CheckCircleIcon,
    ExclamationCircleIcon,
    InformationCircleIcon,
    ExclamationTriangleIcon
  },
  props: {
    flash: Object
  },
  data() {
    return {
      isVisible: false,
      isErrorVisible: false,
      timeout: null
    };
  },
  methods: {
    toggle() {
      this.isVisible = false;
      this.isErrorVisible = false;
    }
  },
  watch: {
    flash: {
      deep: true,
      handler(newVal) {
        this.isVisible = true;
        this.isErrorVisible = true;
        if (this.timeout) {
          clearTimeout(this.timeout);
        }
        this.timeout = setTimeout(() => {
          this.isVisible = false;
        }, 3e3);
      }
    }
  }
};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_CheckCircleIcon = resolveComponent("CheckCircleIcon");
  const _component_XMarkIcon = resolveComponent("XMarkIcon");
  const _component_InformationCircleIcon = resolveComponent("InformationCircleIcon");
  const _component_ExclamationTriangleIcon = resolveComponent("ExclamationTriangleIcon");
  const _component_ExclamationCircleIcon = resolveComponent("ExclamationCircleIcon");
  _push(`<!--[-->`);
  if ($props.flash.success && $data.isVisible) {
    _push(`<div class="absolute top-4 right-4 w-8/12 md:w-6/12 lg:w-3/12 z-[100]"><div class="flex p-4 justify-between items-center bg-green-600 rounded-lg"><div>`);
    _push(ssrRenderComponent(_component_CheckCircleIcon, {
      class: "h-8 w-8 text-white",
      fill: "currentColor"
    }, null, _parent));
    _push(`</div><div class="mx-3 text-sm font-medium text-white">${$props.flash.success}</div><button type="button" class="ml-auto bg-white/20 text-white rounded-lg focus:ring-2 focus:ring-white/50 p-1.5 hover:bg-white/30 h-8 w-8"><span class="sr-only">Close</span>`);
    _push(ssrRenderComponent(_component_XMarkIcon, { class: "w-5 h-5" }, null, _parent));
    _push(`</button></div></div>`);
  } else {
    _push(`<!---->`);
  }
  if ($props.flash.info && $data.isVisible) {
    _push(`<div class="absolute top-4 right-4 w-8/12 md:w-6/12 lg:w-3/12 z-[100]"><div class="flex p-4 justify-between items-center bg-primary rounded-lg"><div>`);
    _push(ssrRenderComponent(_component_InformationCircleIcon, {
      class: "h-8 w-8 text-white",
      fill: "currentColor"
    }, null, _parent));
    _push(`</div><div class="mx-3 text-sm font-medium text-white">${$props.flash.info}</div><button type="button" class="ml-auto bg-white/20 text-white rounded-lg focus:ring-2 focus:ring-white/50 p-1.5 hover:bg-white/30 h-8 w-8"><span class="sr-only">Close</span>`);
    _push(ssrRenderComponent(_component_XMarkIcon, { class: "w-5 h-5" }, null, _parent));
    _push(`</button></div></div>`);
  } else {
    _push(`<!---->`);
  }
  if ($props.flash.warning && $data.isVisible) {
    _push(`<div class="absolute top-4 right-4 w-8/12 md:w-6/12 lg:w-3/12 z-[100]"><div class="flex p-4 justify-between items-center bg-amber-600 rounded-lg"><div>`);
    _push(ssrRenderComponent(_component_ExclamationTriangleIcon, {
      class: "h-8 w-8 text-white",
      fill: "currentColor"
    }, null, _parent));
    _push(`</div><div class="mx-3 text-sm font-medium text-white">${$props.flash.warning}</div><button type="button" class="ml-auto bg-white/20 text-white rounded-lg focus:ring-2 focus:ring-white/50 p-1.5 hover:bg-white/30 h-8 w-8"><span class="sr-only">Close</span>`);
    _push(ssrRenderComponent(_component_XMarkIcon, { class: "w-5 h-5" }, null, _parent));
    _push(`</button></div></div>`);
  } else {
    _push(`<!---->`);
  }
  if ($props.flash.error && $data.isErrorVisible) {
    _push(`<div class="absolute top-4 right-4 w-8/12 md:w-6/12 lg:w-3/12 z-[100]"><div class="flex p-4 justify-between items-center bg-red-600 rounded-lg"><div>`);
    _push(ssrRenderComponent(_component_ExclamationCircleIcon, {
      class: "h-8 w-8 text-white",
      fill: "currentColor"
    }, null, _parent));
    _push(`</div><div class="mx-3 text-sm font-medium text-white">${$props.flash.error}</div><button type="button" class="ml-auto bg-white/20 text-white rounded-lg focus:ring-2 focus:ring-white/50 p-1.5 hover:bg-white/30 h-8 w-8">`);
    _push(ssrRenderComponent(_component_XMarkIcon, { class: "w-5 h-5" }, null, _parent));
    _push(`</button></div></div>`);
  } else {
    _push(`<!---->`);
  }
  _push(`<!--]-->`);
}
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Toast.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const Toast = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["ssrRender", _sfc_ssrRender$1]]);
const _sfc_main$3 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<footer${ssrRenderAttrs(mergeProps({ class: "sticky top-[100vh] border-t border-gray-200 dark:border-gray-800 text-gray-500 dark:text-gray-300" }, _attrs))}><div class="flex items-center justify-center sm:justify-end max-w-7xl mx-auto p-4 sm:px-6 lg:px-8"><p class="text-center"><a href="https://ent.pens.ac.id" target="_blank" class="font-bold">Media ENT</a> ©️ ${ssrInterpolate(new Date().getFullYear())} <a href="https://github.com/erikwibowo" target="_blank" class="font-bold text-primary">Web Master</a></p></div></footer>`);
}
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Footer.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const Footer = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["ssrRender", _sfc_ssrRender]]);
const _sfc_main$2 = {
  __name: "BackToTopButton",
  __ssrInlineRender: true,
  setup(__props) {
    const data = reactive({
      show: false
    });
    window.addEventListener("scroll", () => {
      let scrollPos = window.scrollY;
      if (scrollPos > 0) {
        data.show = true;
      } else {
        data.show = false;
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<a${ssrRenderAttrs(mergeProps({
        style: data.show ? null : { display: "none" },
        class: "h-14 w-14 bg-primary fixed justify-center items-center z-[9999] bottom-4 right-4 rounded-full p-4 text-white hover:bg-primary cursor-pointer"
      }, _attrs))}>`);
      _push(ssrRenderComponent(unref(ArrowSmallUpIcon), { class: "w-6 h-6" }, null, _parent));
      _push(`</a>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/BackToTopButton.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = {
  __name: "AuthenticatedLayout",
  __ssrInlineRender: true,
  emits: ["close", "open"],
  setup(__props, { emit }) {
    const sidebarOpened = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex w-full overflow-hidden" }, _attrs))}>`);
      _push(ssrRenderComponent(_sfc_main$5, {
        open: sidebarOpened.value,
        onClose: ($event) => sidebarOpened.value = false
      }, null, _parent));
      _push(`<div class="pl-0 lg:pl-64 w-full min-h-screen block bg-gray-100 dark:bg-gray-900">`);
      _push(ssrRenderComponent(Toast, {
        flash: _ctx.$page.props.flash
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$7, {
        open: sidebarOpened.value,
        onOpen: ($event) => sidebarOpened.value = true
      }, null, _parent));
      _push(`<main class="max-w-7xl mx-auto sm:px-6 lg:px-8 pb-10 text-gray-900 dark:text-gray-100 text-sm">`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(ssrRenderComponent(_sfc_main$2, null, null, _parent));
      _push(`</main>`);
      _push(ssrRenderComponent(Footer, null, null, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Layouts/AuthenticatedLayout.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {
  __name: "Breadcrumb",
  __ssrInlineRender: true,
  props: {
    title: String,
    breadcrumbs: Object
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex items-center justify-between py-4 px-4 sm:px-0 text-gray-500 dark:text-gray-300" }, _attrs))}><p>${ssrInterpolate(__props.title)}</p><div class="hidden sm:flex space-x-2 items-center">`);
      _push(ssrRenderComponent(unref(Link), {
        href: _ctx.route("dashboard"),
        style: __props.breadcrumbs.length != 0 ? null : { display: "none" }
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Dashboard `);
          } else {
            return [
              createTextVNode(" Dashboard ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--[-->`);
      ssrRenderList(__props.breadcrumbs, (breadcrumb, index) => {
        _push(`<div class="flex items-center space-x-2">`);
        _push(ssrRenderComponent(unref(ChevronRightIcon), { class: "w-3 h-3" }, null, _parent));
        _push(ssrRenderComponent(unref(Link), {
          href: breadcrumb.href
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(breadcrumb.label)}`);
            } else {
              return [
                createTextVNode(toDisplayString(breadcrumb.label), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</div>`);
      });
      _push(`<!--]--></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Breadcrumb.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main$1 as _,
  _sfc_main as a
};
