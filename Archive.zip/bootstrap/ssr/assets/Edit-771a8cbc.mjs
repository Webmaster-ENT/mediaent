import { unref, withCtx, createTextVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrRenderAttr } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./InputLabel-fec3cbb9.mjs";
import { _ as _sfc_main$2 } from "./TextInput-a82a0582.mjs";
import { useForm, Head, Link } from "@inertiajs/inertia-vue3";
import { _ as _sfc_main$3 } from "./Ckeditor-4f66a042.mjs";
import { ChevronLeftIcon } from "@heroicons/vue/24/solid";
import "@inertiajs/inertia";
import "@ckeditor/ckeditor5-build-classic";
import "@ckeditor/ckeditor5-vue";
const __default__ = {
  props: ["id"],
  data() {
    return {
      previewimage: null
    };
  },
  methods: {
    upload(e) {
      let files = e.target.files[0];
      this.previewimage = URL.createObjectURL(files);
    }
  }
};
const _sfc_main = /* @__PURE__ */ Object.assign(__default__, {
  __name: "Edit",
  __ssrInlineRender: true,
  props: {
    article: Object,
    categories: Array,
    thumbnail: String
  },
  setup(__props) {
    const props = __props;
    const form = useForm({
      id: props.article.id,
      title: props.article.title,
      category_id: props.article.category_id,
      body: props.article.body,
      status: props.article.status,
      thumbnail: props.article.thumbnail,
      _method: "put"
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Article" }, null, _parent));
      _push(`<div class="py-5"><div class="mx-auto sm:px-6 lg:px-8"><div class="bg-white overflow-hidden shadow-sm sm:rounded-lg"><div class="p-6 bg-white"><div className="flex items-center justify-between mb-6"><div class="flex justify-between items-center">`);
      _push(ssrRenderComponent(unref(ChevronLeftIcon), { class: "w-4 h-4" }, null, _parent));
      _push(ssrRenderComponent(unref(Link), {
        href: _ctx.route("article.index")
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Back`);
          } else {
            return [
              createTextVNode("Back")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div><form enctype="multipart/form-data"><div className="grid grid-cols-4 gap-4"><div className="col-span-3"><div class="mb-4">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "title",
        value: "Title"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, {
        id: "title",
        type: "text",
        class: "mt-1 block w-full",
        modelValue: unref(form).title,
        "onUpdate:modelValue": ($event) => unref(form).title = $event,
        autofocus: ""
      }, null, _parent));
      if (unref(form).errors.title) {
        _push(`<span className="text-red-600">${ssrInterpolate(unref(form).errors.title)}</span>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div className="mb-4">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "body",
        class: "mb-1",
        value: "Body"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        id: "body",
        modelValue: unref(form).body,
        "onUpdate:modelValue": ($event) => unref(form).body = $event,
        autofocus: ""
      }, null, _parent));
      if (unref(form).errors.body) {
        _push(`<span className="text-red-600">${ssrInterpolate(unref(form).errors.body)}</span>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div><div><div className="mb-4">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "status",
        value: "Status"
      }, null, _parent));
      _push(`<select id="status" class="mt-1 block w-full border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm placeholder:text-gray-400 placeholder:dark:text-gray-400/50"><option value="draft" selected>Draft</option><option value="show">Show</option></select>`);
      if (unref(form).errors.status) {
        _push(`<span className="text-red-600">${ssrInterpolate(unref(form).errors.status)}</span>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div className="mb-4">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "category_id",
        value: "Category"
      }, null, _parent));
      _push(`<select id="category_id" class="mt-1 block w-full border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm placeholder:text-gray-400 placeholder:dark:text-gray-400/50" autofocus><!--[-->`);
      ssrRenderList(__props.categories, (category) => {
        _push(`<option${ssrRenderAttr("value", category.id)}><p>${ssrInterpolate(category.name)}</p></option>`);
      });
      _push(`<!--]--></select>`);
      if (unref(form).errors.category_id) {
        _push(`<span className="text-red-600">${ssrInterpolate(unref(form).errors.category_id)}</span>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div className="mb-4">`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "thumbnail",
        value: "Thumbnail"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, {
        id: "thumbnail",
        type: "file",
        class: "mt-1 block w-full rounded-none shadow-none",
        name: "thumbnail",
        onChange: _ctx.upload,
        onInput: ($event) => unref(form).thumbnail = $event.target.files[0],
        multiple: ""
      }, null, _parent));
      _push(`<img${ssrRenderAttr(
        "src",
        _ctx.previewimage == null ? "../../" + unref(form).thumbnail : _ctx.previewimage
      )} alt="" class="w-30 mt-4 rounded-md">`);
      if (unref(form).errors.thumbnail) {
        _push(`<span className="text-red-600">${ssrInterpolate(unref(form).errors.thumbnail)}</span>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div><div className="mt-4"><button type="submit" className="inline-flex items-center px-4 py-2 bg-primary dark:bg-primary border border-transparent rounded-md font-semibold text-xs text-white dark:text-white uppercase tracking-widest hover:bg-primary/80 dark:hover:bg-primary/90 focus:bg-primary/80 dark:focus:bg-primary/80 active:bg-primary dark:active:bg-primary/80 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 dark:focus:ring-offset-primary transition ease-in-out duration-150 disabled:bg-primary/80"> Save </button></div></form></div></div></div></div><!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Article/Edit.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
