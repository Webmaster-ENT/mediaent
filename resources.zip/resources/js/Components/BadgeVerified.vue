<script setup>
import { CheckBadgeIcon } from '@heroicons/vue/24/solid';

</script>

<template>
    <CheckBadgeIcon class="ml-[2px] w-4 h-4 text-info dark:text-light" v-show="1" />
</template>
